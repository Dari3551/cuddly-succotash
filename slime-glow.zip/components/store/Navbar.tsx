'use client'
import Link from 'next/link'
import { ShoppingCart, User, Sparkles } from 'lucide-react'
import { useCartStore } from '@/lib/store/cart'
import { useAuthStore } from '@/lib/store/auth'
import { motion } from 'framer-motion'
import { useState } from 'react'

export default function Navbar() {
  const totalItems = useCartStore(s => s.getTotalItems())
  const user = useAuthStore(s => s.user)
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <motion.nav
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="sticky top-0 z-50 glass-card rounded-none border-x-0 border-t-0 px-4 py-3"
    >
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 slime-blob flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #F9A8D4, #EC4899)' }}>
            <Sparkles size={18} className="text-white" />
          </div>
          <div>
            <div className="font-black text-lg leading-none" style={{ color: 'var(--text)' }}>
              Slime & Glow
            </div>
            <div className="text-xs font-medium" style={{ color: 'var(--primary-dark)' }}>
              رفحاء
            </div>
          </div>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-6">
          <Link href="/" className="font-semibold hover:text-pink-500 transition-colors">الرئيسية</Link>
          <Link href="/products" className="font-semibold hover:text-pink-500 transition-colors">المنتجات</Link>
          <Link href="/orders" className="font-semibold hover:text-pink-500 transition-colors">طلباتي</Link>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          {/* Cart */}
          <Link href="/cart" className="relative">
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="w-11 h-11 glass-card flex items-center justify-center cursor-pointer"
              style={{ borderRadius: '14px' }}
            >
              <ShoppingCart size={20} style={{ color: 'var(--primary-dark)' }} />
              {totalItems > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1.5 -left-1.5 w-5 h-5 flex items-center justify-center text-white text-xs font-black rounded-full"
                  style={{ background: 'var(--primary-dark)' }}
                >
                  {totalItems}
                </motion.span>
              )}
            </motion.div>
          </Link>

          {/* User */}
          <Link href={user ? '/orders' : '/auth'}>
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="w-11 h-11 glass-card flex items-center justify-center cursor-pointer"
              style={{ borderRadius: '14px' }}
            >
              <User size={20} style={{ color: 'var(--primary-dark)' }} />
            </motion.div>
          </Link>
        </div>
      </div>
    </motion.nav>
  )
}
