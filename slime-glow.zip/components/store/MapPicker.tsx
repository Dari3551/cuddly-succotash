'use client'
import { useEffect, useRef } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

// Fix Leaflet icon issue in Next.js
delete (L.Icon.Default.prototype as any)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
})

const RAFHA_CENTER = { lat: 29.6267, lng: 43.4915 }
const RAFHA_RADIUS = 15000

interface Props {
  center: { lat: number; lng: number }
  onSelect: (lat: number, lng: number, address: string) => void
  selected: { lat: number; lng: number; address: string } | null
}

export default function MapPicker({ center, onSelect, selected }: Props) {
  const mapRef = useRef<L.Map | null>(null)
  const markerRef = useRef<L.Marker | null>(null)
  const circleRef = useRef<L.Circle | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return

    const map = L.map(containerRef.current).setView([center.lat, center.lng], 13)
    mapRef.current = map

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap',
    }).addTo(map)

    // Draw Rafha boundary circle
    const circle = L.circle([RAFHA_CENTER.lat, RAFHA_CENTER.lng], {
      color: '#EC4899',
      fillColor: '#F9A8D4',
      fillOpacity: 0.1,
      radius: RAFHA_RADIUS,
      weight: 2,
    }).addTo(map)
    circleRef.current = circle

    const isInside = (lat: number, lng: number) => {
      const R = 6371000
      const dLat = (lat - RAFHA_CENTER.lat) * Math.PI / 180
      const dLng = (lng - RAFHA_CENTER.lng) * Math.PI / 180
      const a = Math.sin(dLat/2)**2 +
        Math.cos(RAFHA_CENTER.lat * Math.PI / 180) * Math.cos(lat * Math.PI / 180) *
        Math.sin(dLng/2)**2
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)) <= RAFHA_RADIUS
    }

    const customIcon = L.divIcon({
      html: '<div style="background:#EC4899;width:32px;height:32px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:3px solid white;box-shadow:0 4px 12px rgba(236,72,153,0.5)"></div>',
      iconSize: [32, 32],
      iconAnchor: [16, 32],
      className: '',
    })

    map.on('click', async (e) => {
      const { lat, lng } = e.latlng
      if (!isInside(lat, lng)) {
        onSelect(lat, lng, '')
        return
      }

      if (markerRef.current) {
        markerRef.current.setLatLng([lat, lng])
      } else {
        markerRef.current = L.marker([lat, lng], { icon: customIcon }).addTo(map)
      }

      // Reverse geocode
      try {
        const res = await fetch(
          `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=ar`
        )
        const data = await res.json()
        const address = data.display_name || `${lat.toFixed(4)}, ${lng.toFixed(4)}`
        onSelect(lat, lng, address)
      } catch {
        onSelect(lat, lng, `${lat.toFixed(4)}, ${lng.toFixed(4)}`)
      }
    })

    return () => {
      map.remove()
      mapRef.current = null
    }
  }, [])

  return (
    <div style={{ position: 'relative', height: '100%', width: '100%' }}>
      <div ref={containerRef} style={{ height: '100%', width: '100%', minHeight: '260px' }} />
      {!selected && (
        <div style={{
          position: 'absolute',
          bottom: 12,
          right: 12,
          zIndex: 1000,
          background: 'rgba(255,255,255,0.9)',
          padding: '8px 14px',
          borderRadius: 12,
          fontFamily: 'Tajawal',
          fontSize: 13,
          fontWeight: 700,
          color: '#EC4899',
          border: '1.5px solid #F9A8D4',
          backdropFilter: 'blur(8px)',
        }}>
          📍 اضغطي على الخريطة لتحديد موقعك
        </div>
      )}
    </div>
  )
}
