'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Grid3X3, ShoppingCart, User, Package } from 'lucide-react'
import { useCartStore } from '@/lib/store/cart'
import { useAuthStore } from '@/lib/store/auth'
import { motion } from 'framer-motion'

const navItems = [
  { href: '/', icon: Home, label: 'الرئيسية' },
  { href: '/products', icon: Grid3X3, label: 'المنتجات' },
  { href: '/cart', icon: ShoppingCart, label: 'السلة', hasCart: true },
  { href: '/orders', icon: Package, label: 'طلباتي' },
  { href: '/auth', icon: User, label: 'حسابي', isAuth: true },
]

export default function MobileNav() {
  const pathname = usePathname()
  const totalItems = useCartStore(s => s.getTotalItems())
  const user = useAuthStore(s => s.user)

  return (
    <nav className="mobile-nav">
      {navItems.map(({ href, icon: Icon, label, hasCart, isAuth }) => {
        const isActive = pathname === href
        const targetHref = isAuth && user ? '/orders' : href

        return (
          <Link key={href} href={targetHref} className="flex flex-col items-center gap-0.5 relative px-3 py-1">
            <motion.div
              whileTap={{ scale: 0.85 }}
              className={`w-8 h-8 flex items-center justify-center rounded-xl transition-all ${
                isActive ? 'bg-pink-100' : ''
              }`}
            >
              <Icon
                size={22}
                style={{ color: isActive ? 'var(--primary-dark)' : '#9CA3AF' }}
                strokeWidth={isActive ? 2.5 : 2}
              />
              {hasCart && totalItems > 0 && (
                <span className="absolute -top-0.5 right-1.5 w-4 h-4 flex items-center justify-center text-white text-[10px] font-black rounded-full"
                  style={{ background: 'var(--primary-dark)' }}>
                  {totalItems}
                </span>
              )}
            </motion.div>
            <span className={`text-[10px] font-semibold ${isActive ? 'text-pink-600' : 'text-gray-400'}`}>
              {label}
            </span>
          </Link>
        )
      })}
    </nav>
  )
}
