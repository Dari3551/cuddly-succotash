'use client'
import { useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'

export default function VisitTracker() {
  useEffect(() => {
    const supabase = createClient()
    supabase.from('page_visits').insert({ user_agent: navigator.userAgent }).then()
  }, [])
  return null
}
