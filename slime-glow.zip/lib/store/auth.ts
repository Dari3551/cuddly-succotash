'use client'
import { create } from 'zustand'
import { Profile } from '@/types'

interface AuthStore {
  user: Profile | null
  setUser: (user: Profile | null) => void
  isAdmin: () => boolean
  isSupervisor: () => boolean
}

export const useAuthStore = create<AuthStore>((set, get) => ({
  user: null,
  setUser: (user) => set({ user }),
  isAdmin: () => get().user?.role === 'admin',
  isSupervisor: () => ['admin', 'supervisor'].includes(get().user?.role || ''),
}))
