# ✨ Slime & Glow - متجر رفحاء

متجر سلايمات وفومات كامل بـ Next.js 14 + TypeScript + Supabase

---

## 🚀 خطوات الإعداد

### 1. إنشاء مشروع Supabase

1. افتحي [supabase.com](https://supabase.com) وأنشئي مشروعاً جديداً
2. اذهبي إلى **SQL Editor** وشغّلي ملف `supabase-schema.sql` بالكامل
3. اذهبي إلى **Storage** وأنشئي 3 buckets:
   - `products` — **Public** ✅
   - `receipts` — **Private** ✅  
   - `categories` — **Public** ✅

### 2. إعداد المشروع

```bash
git clone <your-repo>
cd slime-glow
npm install
cp .env.local.example .env.local
```

عدّلي `.env.local` بمعلومات Supabase من Project Settings → API:

```env
NEXT_PUBLIC_SUPABASE_URL=https://XXXX.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci...
NEXT_PUBLIC_SITE_URL=https://your-site.vercel.app
```

### 3. تشغيل محلياً

```bash
npm run dev
```

افتحي [http://localhost:3000](http://localhost:3000)

---

## 🔑 إعداد حساب الأدمن

بعد تشغيل الموقع:

1. سجّلي حساباً من `/auth`
2. اذهبي إلى Supabase → Table Editor → `profiles`
3. غيّري `role` من `customer` إلى `admin`
4. ادخلي لوحة التحكم من `/admin`

---

## 🌐 النشر على Vercel

1. اضغطي **New Project** في [vercel.com](https://vercel.com)
2. اربطي المشروع من GitHub
3. أضيفي متغيرات البيئة من `.env.local.example`
4. اضغطي **Deploy** ✅

---

## 📱 الصفحات

| الصفحة | الرابط |
|--------|--------|
| الرئيسية | `/` |
| المنتجات | `/products` |
| تفاصيل منتج | `/products/[id]` |
| السلة | `/cart` |
| الطلب | `/checkout` |
| طلباتي | `/orders` |
| تسجيل الدخول | `/auth` |
| لوحة التحكم 🔒 | `/admin` |
| الطلبات (أدمن) | `/admin/orders` |
| المنتجات (أدمن) | `/admin/products` |
| الأقسام (أدمن) | `/admin/categories` |
| أكواد الخصم | `/admin/discounts` |
| المستخدمين | `/admin/users` |
| الإعدادات | `/admin/settings` |

---

## ✅ الميزات

- 🛍️ متجر كامل بأقسام ومنتجات
- 🗺️ تحديد موقع التوصيل بالخريطة (رفحاء فقط)
- 💳 دفع بالتحويل أو الكاش
- 🧾 رفع إيصال التحويل
- 🏷️ أكواد خصم متكاملة
- 📱 تسجيل بكلمة مرور
- 🔔 إشعارات واتساب
- 📊 لوحة تحكم شاملة
- 🎨 ألوان قابلة للتخصيص
- 📱 متوافق مع الجوال والحاسوب
- ☁️ جاهز للنشر على Vercel

---

## 🗄️ Supabase Storage Buckets

أنشئي هذه الـ Buckets في Storage:

| Bucket | Public? | الاستخدام |
|--------|---------|----------|
| `products` | ✅ نعم | صور المنتجات |
| `categories` | ✅ نعم | صور الأقسام |
| `receipts` | ❌ لا | إيصالات التحويل |

---

## 🔧 مشاكل شائعة

**لا تظهر الصور:** تأكدي أن bucket `products` مضبوط على Public

**خطأ في الخريطة:** تأكدي من تثبيت `leaflet` و `react-leaflet`

**المستخدم لا يصل للأدمن:** تأكدي من تغيير `role` في قاعدة البيانات إلى `admin`
