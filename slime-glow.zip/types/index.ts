export interface Profile {
  id: string
  phone: string
  full_name?: string
  role: 'customer' | 'admin' | 'supervisor'
  created_at: string
}

export interface Category {
  id: string
  name: string
  slug: string
  description?: string
  image_url?: string
  sort_order: number
  is_active: boolean
  created_at: string
}

export interface Product {
  id: string
  name: string
  description?: string
  price: number
  stock: number
  category_id?: string
  category?: Category
  images: string[]
  is_active: boolean
  is_featured: boolean
  created_at: string
  updated_at: string
}

export interface DiscountCode {
  id: string
  code: string
  discount_type: 'percentage' | 'fixed'
  discount_value: number
  min_order_amount: number
  max_uses?: number
  used_count: number
  expires_at?: string
  is_active: boolean
  created_at: string
}

export interface CartItem {
  product: Product
  quantity: number
}

export interface DeliveryLocation {
  lat: number
  lng: number
  address: string
}

export interface OrderItem {
  product_id: string
  product_name: string
  product_image?: string
  price: number
  quantity: number
}

export interface Order {
  id: string
  order_number: string
  user_id?: string
  customer_phone: string
  customer_name?: string
  items: OrderItem[]
  subtotal: number
  discount_amount: number
  delivery_fee: number
  total: number
  discount_code?: string
  payment_method: 'transfer' | 'cash'
  payment_status: 'pending' | 'receipt_uploaded' | 'confirmed' | 'rejected'
  order_status: 'pending' | 'preparing' | 'out_for_delivery' | 'delivered' | 'cancelled'
  delivery_address?: string
  delivery_location?: DeliveryLocation
  receipt_url?: string
  notes?: string
  created_at: string
  updated_at: string
}

export interface SiteSetting {
  id: string
  key: string
  value: any
  updated_at: string
}

export interface StoreInfo {
  name: string
  tagline: string
  phone: string
  whatsapp: string
  city: string
}

export interface ThemeSettings {
  primaryColor: string
  secondaryColor: string
  accentColor: string
  bgColor: string
  textColor: string
}

export interface DeliverySettings {
  fee: number
  freeDeliveryAbove: number
  city: string
  estimatedTime: string
}

export interface PaymentSettings {
  methods: ('transfer' | 'cash')[]
  bankName: string
  accountName: string
  accountNumber: string
  iban: string
}

export interface SocialMedia {
  id: string
  platform: string
  url: string
  icon: string
}
