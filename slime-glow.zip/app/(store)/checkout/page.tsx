'use client'
import { useState, useEffect, useRef } from 'react'
import { useCartStore } from '@/lib/store/cart'
import { useAuthStore } from '@/lib/store/auth'
import { createClient } from '@/lib/supabase/client'
import { motion, AnimatePresence } from 'framer-motion'
import { MapPin, CreditCard, Banknote, Upload, CheckCircle, AlertCircle, Navigation } from 'lucide-react'
import { useRouter, useSearchParams } from 'next/navigation'
import toast from 'react-hot-toast'
import dynamic from 'next/dynamic'

const MapPicker = dynamic(() => import('@/components/store/MapPicker'), { 
  ssr: false,
  loading: () => (
    <div className="h-64 bg-pink-50 rounded-2xl flex items-center justify-center">
      <div className="spinner" />
    </div>
  )
})

// Rafha bounds
const RAFHA_CENTER = { lat: 29.6267, lng: 43.4915 }
const RAFHA_RADIUS = 15000 // 15km

export default function CheckoutPage() {
  const { items, getSubtotal, clearCart } = useCartStore()
  const user = useAuthStore(s => s.user)
  const router = useRouter()
  const searchParams = useSearchParams()
  const appliedCode = searchParams.get('code')

  const [step, setStep] = useState(1)
  const [paymentMethod, setPaymentMethod] = useState<'transfer' | 'cash'>('transfer')
  const [location, setLocation] = useState<{ lat: number; lng: number; address: string } | null>(null)
  const [locationError, setLocationError] = useState('')
  const [notes, setNotes] = useState('')
  const [receipt, setReceipt] = useState<File | null>(null)
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null)
  const [paymentSettings, setPaymentSettings] = useState<any>(null)
  const [discountAmount, setDiscountAmount] = useState(0)
  const [submitting, setSubmitting] = useState(false)
  const [orderId, setOrderId] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const subtotal = getSubtotal()
  const deliveryFee = subtotal >= 100 ? 0 : 10
  const total = subtotal - discountAmount + deliveryFee

  useEffect(() => {
    if (!user) { router.push('/auth?redirect=/checkout'); return }
    if (items.length === 0) { router.push('/products'); return }

    const fetchSettings = async () => {
      const supabase = createClient()
      const [{ data: ps }, discountData] = await Promise.all([
        supabase.from('site_settings').select('value').eq('key', 'payment').single(),
        appliedCode
          ? supabase.from('discount_codes').select('*').eq('code', appliedCode).single()
          : Promise.resolve({ data: null })
      ])
      if (ps) setPaymentSettings(ps.value)
      if (discountData?.data) {
        const code = discountData.data
        const disc = code.discount_type === 'percentage'
          ? (subtotal * code.discount_value) / 100
          : code.discount_value
        setDiscountAmount(Math.min(disc, subtotal))
      }
    }
    fetchSettings()
  }, [user, items])

  const isInsideRafha = (lat: number, lng: number) => {
    const R = 6371000
    const dLat = (lat - RAFHA_CENTER.lat) * Math.PI / 180
    const dLng = (lng - RAFHA_CENTER.lng) * Math.PI / 180
    const a = Math.sin(dLat/2)**2 +
      Math.cos(RAFHA_CENTER.lat * Math.PI / 180) * Math.cos(lat * Math.PI / 180) *
      Math.sin(dLng/2)**2
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
    return R * c <= RAFHA_RADIUS
  }

  const handleLocationSelect = (lat: number, lng: number, address: string) => {
    if (!isInsideRafha(lat, lng)) {
      setLocationError('عذراً! نوصّل داخل رفحاء فقط 🚚')
      setLocation(null)
      return
    }
    setLocationError('')
    setLocation({ lat, lng, address })
  }

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 5 * 1024 * 1024) { toast.error('الصورة أكبر من 5MB'); return }
    setReceipt(file)
    setReceiptPreview(URL.createObjectURL(file))
  }

  const handleSubmit = async () => {
    if (!location) { toast.error('حددي موقع التوصيل'); return }
    if (paymentMethod === 'transfer' && !receipt && step === 2) {
      toast.error('ارفعي إيصال التحويل')
      return
    }

    setSubmitting(true)
    const supabase = createClient()

    try {
      let receiptUrl = null
      if (receipt) {
        const fileName = `${Date.now()}_${receipt.name}`
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('receipts')
          .upload(fileName, receipt)
        if (uploadError) throw new Error('فشل رفع الإيصال')
        receiptUrl = supabase.storage.from('receipts').getPublicUrl(fileName).data.publicUrl
      }

      const orderNumber = `SG-${Date.now().toString().slice(-8)}`
      const orderItems = items.map(({ product, quantity }) => ({
        product_id: product.id,
        product_name: product.name,
        product_image: product.images?.[0],
        price: product.price,
        quantity,
      }))

      const { data: order, error } = await supabase.from('orders').insert({
        order_number: orderNumber,
        user_id: user?.id,
        customer_phone: user?.phone,
        customer_name: user?.full_name,
        items: orderItems,
        subtotal,
        discount_amount: discountAmount,
        delivery_fee: deliveryFee,
        total,
        discount_code: appliedCode || null,
        payment_method: paymentMethod,
        payment_status: receipt ? 'receipt_uploaded' : 'pending',
        order_status: 'pending',
        delivery_location: location,
        delivery_address: location.address,
        receipt_url: receiptUrl,
        notes: notes || null,
      }).select().single()

      if (error) throw error

      if (appliedCode) {
        await supabase.from('discount_codes')
          .update({ used_count: supabase.rpc('increment', { x: 1 }) })
          .eq('code', appliedCode)
      }

      clearCart()
      setOrderId(order.id)
      setStep(3)
    } catch (err: any) {
      toast.error(err.message || 'حدث خطأ، حاولي مجدداً')
    }
    setSubmitting(false)
  }

  if (step === 3) {
    return (
      <div className="page-enter min-h-[70vh] flex items-center justify-center px-4">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center max-w-md"
        >
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-8xl mb-6"
          >🎉</motion.div>
          <h2 className="text-3xl font-black mb-3">تم استلام طلبك!</h2>
          <p className="text-gray-500 mb-6 font-medium">
            {paymentMethod === 'transfer'
              ? 'تم استلام إيصالك، سيتم التحقق وتجهيز طلبك قريباً 💖'
              : 'طلبك قيد التجهيز، الدفع عند الاستلام 🚚'}
          </p>
          {paymentSettings && paymentMethod === 'transfer' && !receipt && (
            <div className="glass-card p-5 mb-6 text-right">
              <p className="font-black mb-2 text-pink-600">بيانات التحويل:</p>
              <p className="font-bold">{paymentSettings.bankName}</p>
              <p className="font-semibold text-gray-600">{paymentSettings.accountName}</p>
              <p className="font-mono font-bold">{paymentSettings.iban || paymentSettings.accountNumber}</p>
              <p className="text-2xl font-black mt-2" style={{ color: 'var(--primary-dark)' }}>{total.toFixed(2)} ر.س</p>
            </div>
          )}
          <div className="flex gap-3 justify-center">
            <button onClick={() => router.push('/orders')} className="btn-pink">
              <CheckCircle size={18} />
              متابعة طلباتي
            </button>
            <button onClick={() => router.push('/')} className="btn-outline">
              العودة للرئيسية
            </button>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="page-enter max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-black mb-8">إتمام الطلب 🛍️</h1>

      {/* Steps */}
      <div className="flex items-center gap-2 mb-8">
        {[1, 2].map(s => (
          <div key={s} className={`flex items-center gap-2 ${s < step ? 'text-green-500' : s === step ? 'text-pink-600' : 'text-gray-300'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-sm ${
              s < step ? 'bg-green-100' : s === step ? 'bg-pink-100' : 'bg-gray-100'
            }`}>{s < step ? '✓' : s}</div>
            <span className="font-bold text-sm hidden sm:block">
              {s === 1 ? 'الموقع والطلب' : 'الدفع'}
            </span>
            {s < 2 && <div className="w-8 h-0.5 bg-gray-200 mx-1" />}
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                className="space-y-5"
              >
                <div className="glass-card p-5">
                  <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                    <MapPin size={20} style={{ color: 'var(--primary-dark)' }} />
                    حددي موقع التوصيل
                  </h3>
                  <p className="text-sm text-gray-500 mb-3">🚚 نوصّل داخل رفحاء فقط</p>
                  <div className="h-72 rounded-2xl overflow-hidden">
                    <MapPicker
                      center={RAFHA_CENTER}
                      onSelect={handleLocationSelect}
                      selected={location}
                    />
                  </div>
                  {locationError && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex items-center gap-2 mt-3 p-3 bg-red-50 rounded-xl text-red-500 font-bold text-sm"
                    >
                      <AlertCircle size={16} />
                      {locationError}
                    </motion.div>
                  )}
                  {location && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex items-center gap-2 mt-3 p-3 bg-green-50 rounded-xl text-green-600 font-bold text-sm"
                    >
                      <CheckCircle size={16} />
                      {location.address || 'تم تحديد الموقع ✓'}
                    </motion.div>
                  )}
                </div>

                <div className="glass-card p-5">
                  <h3 className="font-black text-lg mb-3">ملاحظات (اختياري)</h3>
                  <textarea
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="أي ملاحظات للتوصيل..."
                    className="input-pink resize-none h-24"
                  />
                </div>

                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={() => {
                    if (!location) { toast.error('حددي موقع التوصيل'); return }
                    setStep(2)
                  }}
                  className="btn-pink w-full justify-center"
                >
                  متابعة للدفع →
                </motion.button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                className="space-y-5"
              >
                <div className="glass-card p-5">
                  <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                    <CreditCard size={20} style={{ color: 'var(--primary-dark)' }} />
                    طريقة الدفع
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { value: 'transfer', label: 'تحويل بنكي', icon: CreditCard, emoji: '🏦' },
                      { value: 'cash', label: 'كاش عند الاستلام', icon: Banknote, emoji: '💵' },
                    ].map(({ value, label, emoji }) => (
                      <button
                        key={value}
                        onClick={() => setPaymentMethod(value as any)}
                        className={`p-4 rounded-2xl border-2 font-bold text-sm transition-all ${
                          paymentMethod === value
                            ? 'border-pink-500 bg-pink-50 text-pink-700'
                            : 'border-gray-200 hover:border-pink-300'
                        }`}
                      >
                        <div className="text-2xl mb-1">{emoji}</div>
                        {label}
                        {paymentMethod === value && <div className="text-xs text-pink-500 mt-1">✓ محدد</div>}
                      </button>
                    ))}
                  </div>
                </div>

                {paymentMethod === 'transfer' && paymentSettings && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="glass-card p-5"
                  >
                    <h3 className="font-black text-lg mb-3">🏦 بيانات التحويل</h3>
                    <div className="bg-pink-50 rounded-2xl p-4 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-500 font-medium">البنك</span>
                        <span className="font-bold">{paymentSettings.bankName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500 font-medium">اسم الحساب</span>
                        <span className="font-bold">{paymentSettings.accountName}</span>
                      </div>
                      {paymentSettings.iban && (
                        <div className="flex justify-between">
                          <span className="text-gray-500 font-medium">رقم الآيبان</span>
                          <span className="font-mono font-bold text-sm">{paymentSettings.iban}</span>
                        </div>
                      )}
                      {paymentSettings.accountNumber && (
                        <div className="flex justify-between">
                          <span className="text-gray-500 font-medium">رقم الحساب</span>
                          <span className="font-mono font-bold">{paymentSettings.accountNumber}</span>
                        </div>
                      )}
                      <div className="border-t border-pink-200 pt-2 flex justify-between">
                        <span className="font-black">المبلغ المطلوب</span>
                        <span className="font-black text-xl" style={{ color: 'var(--primary-dark)' }}>{total.toFixed(2)} ر.س</span>
                      </div>
                    </div>

                    {/* Receipt upload */}
                    <div className="mt-4">
                      <p className="font-bold mb-2">ارفعي إيصال التحويل:</p>
                      <input ref={fileRef} type="file" accept="image/*" onChange={handleReceiptUpload} className="hidden" />
                      {receiptPreview ? (
                        <div className="relative">
                          <img src={receiptPreview} alt="إيصال" className="w-full h-40 object-cover rounded-2xl" />
                          <button
                            onClick={() => { setReceipt(null); setReceiptPreview(null) }}
                            className="absolute top-2 left-2 bg-red-500 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold"
                          >×</button>
                        </div>
                      ) : (
                        <button onClick={() => fileRef.current?.click()}
                          className="w-full h-32 border-2 border-dashed border-pink-300 rounded-2xl flex flex-col items-center justify-center gap-2 hover:bg-pink-50 transition-colors">
                          <Upload size={24} className="text-pink-400" />
                          <span className="font-bold text-sm text-pink-500">اضغطي لرفع الإيصال</span>
                          <span className="text-xs text-gray-400">JPG, PNG (أقل من 5MB)</span>
                        </button>
                      )}
                    </div>
                  </motion.div>
                )}

                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className="btn-outline flex-1 justify-center">
                    ← رجوع
                  </button>
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={handleSubmit}
                    disabled={submitting || (paymentMethod === 'transfer' && !receipt)}
                    className="btn-pink flex-1 justify-center disabled:opacity-60"
                  >
                    {submitting ? (
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <><CheckCircle size={18} /> تأكيد الطلب</>
                    )}
                  </motion.button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Order Summary */}
        <div className="glass-card p-5 h-fit sticky top-20">
          <h3 className="font-black text-lg mb-4">ملخص الطلب</h3>
          <div className="space-y-3 mb-4">
            {items.map(({ product, quantity }) => (
              <div key={product.id} className="flex gap-2 items-start">
                <div className="w-10 h-10 rounded-xl overflow-hidden bg-pink-50 flex-shrink-0">
                  {product.images?.[0]
                    ? <img src={product.images[0]} alt="" className="w-full h-full object-cover" />
                    : <div className="w-full h-full flex items-center justify-center text-xl">🫧</div>
                  }
                </div>
                <div className="flex-1">
                  <p className="font-bold text-xs line-clamp-1">{product.name}</p>
                  <p className="text-xs text-gray-500">× {quantity}</p>
                </div>
                <span className="font-bold text-sm">{(product.price * quantity).toFixed(0)} ر.س</span>
              </div>
            ))}
          </div>
          <div className="border-t border-pink-100 pt-3 space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-gray-500">المجموع</span><span className="font-bold">{subtotal.toFixed(2)} ر.س</span></div>
            {discountAmount > 0 && <div className="flex justify-between text-green-600"><span>خصم</span><span className="font-bold">- {discountAmount.toFixed(2)} ر.س</span></div>}
            <div className="flex justify-between"><span className="text-gray-500">التوصيل</span><span className="font-bold">{deliveryFee === 0 ? 'مجاني' : `${deliveryFee} ر.س`}</span></div>
            <div className="flex justify-between font-black text-lg pt-2 border-t border-pink-100">
              <span>الإجمالي</span>
              <span style={{ color: 'var(--primary-dark)' }}>{total.toFixed(2)} ر.س</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
