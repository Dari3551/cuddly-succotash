'use client'
import { useState } from 'react'
import { useCartStore } from '@/lib/store/cart'
import { useAuthStore } from '@/lib/store/auth'
import { motion, AnimatePresence } from 'framer-motion'
import { Trash2, Plus, Minus, ShoppingBag, Tag, ArrowLeft } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'

export default function CartPage() {
  const { items, removeItem, updateQuantity, clearCart, getSubtotal } = useCartStore()
  const user = useAuthStore(s => s.user)
  const router = useRouter()
  const [discountCode, setDiscountCode] = useState('')
  const [discountAmount, setDiscountAmount] = useState(0)
  const [appliedCode, setAppliedCode] = useState('')
  const [checkingCode, setCheckingCode] = useState(false)

  const subtotal = getSubtotal()
  const deliveryFee = subtotal >= 100 ? 0 : 10
  const total = subtotal - discountAmount + deliveryFee

  const applyDiscount = async () => {
    if (!discountCode.trim()) return
    setCheckingCode(true)
    const supabase = createClient()
    const { data: code } = await supabase
      .from('discount_codes')
      .select('*')
      .eq('code', discountCode.toUpperCase())
      .eq('is_active', true)
      .single()

    if (!code) {
      toast.error('كود الخصم غير صحيح أو منتهي')
      setCheckingCode(false)
      return
    }

    if (code.expires_at && new Date(code.expires_at) < new Date()) {
      toast.error('انتهت صلاحية الكود')
      setCheckingCode(false)
      return
    }

    if (subtotal < code.min_order_amount) {
      toast.error(`الحد الأدنى للطلب ${code.min_order_amount} ر.س`)
      setCheckingCode(false)
      return
    }

    if (code.max_uses && code.used_count >= code.max_uses) {
      toast.error('تجاوز الكود الحد الأقصى')
      setCheckingCode(false)
      return
    }

    const discount = code.discount_type === 'percentage'
      ? (subtotal * code.discount_value) / 100
      : code.discount_value

    setDiscountAmount(Math.min(discount, subtotal))
    setAppliedCode(discountCode.toUpperCase())
    toast.success(`خصم ${code.discount_value}${code.discount_type === 'percentage' ? '%' : ' ر.س'} مطبّق 🎉`)
    setCheckingCode(false)
  }

  const handleCheckout = () => {
    if (items.length === 0) return
    if (!user) {
      router.push('/auth?redirect=/checkout')
      return
    }
    router.push('/checkout' + (appliedCode ? `?code=${appliedCode}` : ''))
  }

  if (items.length === 0) {
    return (
      <div className="page-enter max-w-2xl mx-auto px-4 py-20 text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="text-8xl mb-6"
        >🛒</motion.div>
        <h2 className="text-2xl font-black mb-3">السلة فارغة</h2>
        <p className="text-gray-500 mb-8">أضيفي منتجات لتبدأ التسوق</p>
        <Link href="/products" className="btn-pink">
          <ShoppingBag size={20} />
          تسوّقي الآن
        </Link>
      </div>
    )
  }

  return (
    <div className="page-enter max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-black mb-8 flex items-center gap-3">
        <ShoppingBag size={32} style={{ color: 'var(--primary-dark)' }} />
        سلة التسوق
        <span className="badge">{items.length}</span>
      </h1>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Items */}
        <div className="md:col-span-2 space-y-3">
          <AnimatePresence>
            {items.map(({ product, quantity }) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                className="glass-card p-4 flex gap-4"
              >
                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-pink-50 flex-shrink-0">
                  {product.images?.[0] ? (
                    <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-3xl">🫧</div>
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold mb-1">{product.name}</h3>
                  <p className="font-black text-lg" style={{ color: 'var(--primary-dark)' }}>
                    {product.price} ر.س
                  </p>
                  <div className="flex items-center gap-3 mt-2">
                    <button onClick={() => updateQuantity(product.id, quantity - 1)}
                      className="w-8 h-8 rounded-xl glass-card flex items-center justify-center">
                      <Minus size={14} />
                    </button>
                    <span className="font-black w-6 text-center">{quantity}</span>
                    <button onClick={() => updateQuantity(product.id, quantity + 1)}
                      className="w-8 h-8 rounded-xl glass-card flex items-center justify-center">
                      <Plus size={14} />
                    </button>
                    <button onClick={() => removeItem(product.id)}
                      className="mr-auto w-8 h-8 rounded-xl bg-red-50 flex items-center justify-center text-red-400 hover:bg-red-100">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Summary */}
        <div className="glass-card p-5 h-fit sticky top-20">
          <h3 className="font-black text-lg mb-4">ملخص الطلب</h3>

          {/* Discount code */}
          <div className="mb-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={discountCode}
                onChange={e => setDiscountCode(e.target.value)}
                placeholder="كود الخصم"
                className="input-pink flex-1 !py-2"
              />
              <button onClick={applyDiscount} disabled={checkingCode}
                className="btn-pink !py-2 !px-4 !text-sm disabled:opacity-60">
                {checkingCode ? '...' : 'تطبيق'}
              </button>
            </div>
            {appliedCode && (
              <div className="flex items-center gap-2 mt-2 text-green-600 text-sm font-bold">
                <Tag size={14} />
                كود {appliedCode} مطبّق ✓
              </div>
            )}
          </div>

          <div className="space-y-2 text-sm border-t border-pink-100 pt-4">
            <div className="flex justify-between">
              <span className="text-gray-500">المجموع</span>
              <span className="font-bold">{subtotal.toFixed(2)} ر.س</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>الخصم</span>
                <span className="font-bold">- {discountAmount.toFixed(2)} ر.س</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-gray-500">التوصيل</span>
              <span className="font-bold">
                {deliveryFee === 0 ? <span className="text-green-600">مجاني 🎉</span> : `${deliveryFee} ر.س`}
              </span>
            </div>
            {subtotal < 100 && deliveryFee > 0 && (
              <p className="text-xs text-pink-400">
                أضيفي منتجات بـ {(100 - subtotal).toFixed(0)} ر.س للتوصيل المجاني
              </p>
            )}
          </div>

          <div className="flex justify-between font-black text-xl mt-4 border-t border-pink-100 pt-4">
            <span>الإجمالي</span>
            <span style={{ color: 'var(--primary-dark)' }}>{total.toFixed(2)} ر.س</span>
          </div>

          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleCheckout}
            className="btn-pink w-full mt-5 justify-center text-base"
          >
            <ArrowLeft size={18} />
            {user ? 'متابعة الطلب' : 'سجّلي للمتابعة'}
          </motion.button>

          {!user && (
            <p className="text-center text-xs text-gray-400 mt-2">
              سجّلي أو أنشئي حساباً للمتابعة
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
