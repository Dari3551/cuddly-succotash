'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Product } from '@/types'
import { motion } from 'framer-motion'
import { ShoppingCart, ArrowRight, Minus, Plus, Package } from 'lucide-react'
import { useCartStore } from '@/lib/store/cart'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import Link from 'next/link'

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [qty, setQty] = useState(1)
  const [activeImg, setActiveImg] = useState(0)
  const addItem = useCartStore(s => s.addItem)
  const router = useRouter()

  useEffect(() => {
    const fetchProduct = async () => {
      const supabase = createClient()
      const { data } = await supabase
        .from('products')
        .select('*, category:categories(*)')
        .eq('id', params.id)
        .single()
      setProduct(data)
      setLoading(false)
    }
    fetchProduct()
  }, [params.id])

  if (loading) return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="spinner" />
    </div>
  )

  if (!product) return (
    <div className="text-center py-20">
      <div className="text-6xl mb-4">😕</div>
      <p className="font-bold text-xl">المنتج غير موجود</p>
      <Link href="/products" className="btn-pink mt-4 inline-flex">العودة للمنتجات</Link>
    </div>
  )

  return (
    <div className="page-enter max-w-5xl mx-auto px-4 py-8">
      <Link href="/products" className="flex items-center gap-2 text-pink-500 font-bold mb-6 hover:gap-3 transition-all">
        <ArrowRight size={18} />
        العودة للمنتجات
      </Link>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Images */}
        <div>
          <motion.div
            className="rounded-3xl overflow-hidden h-80 md:h-96 bg-pink-50 mb-3"
            layoutId={`product-${product.id}`}
          >
            {product.images?.[activeImg] ? (
              <img src={product.images[activeImg]} alt={product.name}
                className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-8xl">🫧</div>
            )}
          </motion.div>
          {product.images?.length > 1 && (
            <div className="flex gap-2 overflow-x-auto">
              {product.images.map((img, i) => (
                <button key={i} onClick={() => setActiveImg(i)}
                  className={`flex-shrink-0 w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${
                    activeImg === i ? 'border-pink-500' : 'border-transparent'
                  }`}>
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          {product.category && (
            <span className="badge mb-3 inline-block">{product.category.name}</span>
          )}
          <h1 className="text-2xl md:text-3xl font-black mb-3">{product.name}</h1>
          {product.description && (
            <p className="text-gray-600 leading-relaxed mb-4">{product.description}</p>
          )}

          <div className="glass-card p-4 mb-6">
            <div className="flex items-center justify-between">
              <span className="font-bold text-gray-500">السعر</span>
              <span className="text-3xl font-black" style={{ color: 'var(--primary-dark)' }}>
                {product.price} ر.س
              </span>
            </div>
            <div className="flex items-center justify-between mt-2">
              <span className="font-bold text-gray-500">المخزون</span>
              <div className="flex items-center gap-1">
                <Package size={16} className={product.stock > 0 ? 'text-green-500' : 'text-red-400'} />
                <span className={`font-bold ${product.stock > 0 ? 'text-green-600' : 'text-red-500'}`}>
                  {product.stock > 0 ? `${product.stock} متاح` : 'نفذت الكمية'}
                </span>
              </div>
            </div>
          </div>

          {/* Quantity */}
          {product.stock > 0 && (
            <div className="flex items-center gap-4 mb-6">
              <span className="font-bold">الكمية:</span>
              <div className="flex items-center gap-2">
                <button onClick={() => setQty(q => Math.max(1, q - 1))}
                  className="w-9 h-9 rounded-xl glass-card flex items-center justify-center font-black">
                  <Minus size={16} />
                </button>
                <span className="font-black text-xl w-8 text-center">{qty}</span>
                <button onClick={() => setQty(q => Math.min(product.stock, q + 1))}
                  className="w-9 h-9 rounded-xl glass-card flex items-center justify-center font-black">
                  <Plus size={16} />
                </button>
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                if (product.stock === 0) return
                addItem(product, qty)
                toast.success(`أضيف ${qty} للسلة 🛒`)
              }}
              disabled={product.stock === 0}
              className="btn-pink flex-1 disabled:opacity-50"
            >
              <ShoppingCart size={20} />
              أضف للسلة
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                if (product.stock === 0) return
                addItem(product, qty)
                router.push('/cart')
              }}
              disabled={product.stock === 0}
              className="btn-outline flex-1 disabled:opacity-50"
            >
              اطلبي الآن
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  )
}
