'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Product, Category } from '@/types'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, Filter, ShoppingCart } from 'lucide-react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { useCartStore } from '@/lib/store/cart'
import toast from 'react-hot-toast'

export default function ProductsPage() {
  const searchParams = useSearchParams()
  const categorySlug = searchParams.get('category')
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [activeCategory, setActiveCategory] = useState<string | null>(categorySlug)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const addItem = useCartStore(s => s.addItem)

  useEffect(() => {
    fetchData()
  }, [activeCategory])

  const fetchData = async () => {
    setLoading(true)
    const supabase = createClient()
    const [{ data: cats }, productsQuery] = await Promise.all([
      supabase.from('categories').select('*').eq('is_active', true).order('sort_order'),
      (async () => {
        let q = supabase.from('products').select('*, category:categories(*)').eq('is_active', true).order('created_at', { ascending: false })
        if (activeCategory) {
          const { data: cat } = await supabase.from('categories').select('id').eq('slug', activeCategory).single()
          if (cat) q = q.eq('category_id', cat.id)
        }
        return q
      })()
    ])
    setCategories(cats || [])
    setProducts(productsQuery.data || [])
    setLoading(false)
  }

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.description?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="page-enter max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-black mb-6 flex items-center gap-2">
        <span className="text-4xl">🫧</span> جميع المنتجات
      </h1>

      {/* Search */}
      <div className="relative mb-6">
        <Search size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="ابحثي عن منتج..."
          className="input-pink pr-12"
        />
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-6">
        <button
          onClick={() => setActiveCategory(null)}
          className={`flex-shrink-0 px-4 py-2 rounded-2xl font-bold text-sm transition-all ${
            !activeCategory ? 'btn-pink !py-2' : 'glass-card'
          }`}
        >
          الكل
        </button>
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.slug)}
            className={`flex-shrink-0 px-4 py-2 rounded-2xl font-bold text-sm transition-all ${
              activeCategory === cat.slug ? 'btn-pink !py-2' : 'glass-card'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="product-card h-64 animate-pulse bg-pink-50" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 glass-card">
          <div className="text-6xl mb-4">🔍</div>
          <p className="text-gray-500 font-bold text-lg">لا توجد منتجات</p>
        </div>
      ) : (
        <motion.div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          <AnimatePresence>
            {filtered.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: i * 0.05 }}
                className="product-card"
              >
                <Link href={`/products/${product.id}`}>
                  <div className="relative h-44 bg-pink-50 overflow-hidden">
                    {product.images?.[0] ? (
                      <img src={product.images[0]} alt={product.name}
                        className="w-full h-full object-cover transition-transform duration-300 hover:scale-110" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-5xl">🫧</div>
                    )}
                    {product.stock === 0 && (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <span className="bg-white font-bold px-3 py-1 rounded-full text-sm">نفذت الكمية</span>
                      </div>
                    )}
                    {product.category && (
                      <div className="absolute top-2 right-2">
                        <span className="badge text-xs">{product.category.name}</span>
                      </div>
                    )}
                  </div>
                </Link>
                <div className="p-3">
                  <Link href={`/products/${product.id}`}>
                    <h3 className="font-bold text-sm mb-1 line-clamp-2 hover:text-pink-600">{product.name}</h3>
                  </Link>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-black" style={{ color: 'var(--primary-dark)' }}>
                      {product.price} ر.س
                    </span>
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => {
                        if (product.stock === 0) return
                        addItem(product)
                        toast.success('أضيف للسلة 🛒')
                      }}
                      disabled={product.stock === 0}
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-white disabled:opacity-40"
                      style={{ background: 'var(--primary-dark)' }}
                    >
                      <ShoppingCart size={15} />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  )
}
