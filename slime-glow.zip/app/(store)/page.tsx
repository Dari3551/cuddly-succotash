'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Product, Category, SocialMedia } from '@/types'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { Sparkles, Star, ChevronLeft, Instagram, Youtube, Facebook } from 'lucide-react'
import { useCartStore } from '@/lib/store/cart'
import toast from 'react-hot-toast'

const SocialIcon = ({ platform }: { platform: string }) => {
  const icons: Record<string, React.ReactNode> = {
    instagram: <Instagram size={20} />,
    tiktok: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.31 6.31 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.83a8.16 8.16 0 004.77 1.53V6.9a4.85 4.85 0 01-1-.21z"/></svg>,
    youtube: <Youtube size={20} />,
    facebook: <Facebook size={20} />,
    twitter: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>,
    snapchat: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M12.166.006C9.315.006 6.706 1.108 4.874 3.086 3.041 5.065 2.11 7.66 2.23 10.51c.022.513.073 1.02.154 1.516-.434.228-.958.356-1.548.356-.324 0-.624-.046-.836-.13-.082-.031-.165-.047-.246-.047-.396 0-.754.317-.754.729 0 .376.295.672.65.72.016.002 1.65.254 2.396 1.93.037.082.11.198.234.21.278.026.58-.226 1.11-.226.18 0 .38.025.594.082l.01.003c.133.038.268.057.4.057.616 0 1.21-.377 1.677-1.062l.026-.038c.113-.166.167-.241.184-.258.024.027.066.085.14.198.135.203.33.497.492.728.273.392.46.75.46.75s-1.048.287-1.672.913c-.2.201-.297.394-.287.575.017.338.36.602 1.02.786.196.055.37.2.37.396 0 .024-.003.05-.01.077-.06.263-.282.527-.637.527-.065 0-.137-.01-.214-.031-.196-.054-.358-.08-.498-.08-.302 0-.537.107-.7.317-.178.23-.185.483-.185.484v.018c-.008.493.458 1.013 1.398 1.561.94.548 2.2.99 3.73 1.31.102.023.17.112.17.218 0 .03-.007.06-.02.088-.088.2-.363.366-.8.48a4.1 4.1 0 01-.993.132c-.215 0-.439-.02-.665-.06-.16-.027-.322-.041-.483-.041-.454 0-.852.152-1.153.44-.225.21-.34.457-.34.73 0 .032.003.065.007.098.12.988 1.625 1.488 2.974 1.488h.058c1.38 0 2.818-.514 2.818-1.516a.51.51 0 00-.005-.074c.217.016.44.024.665.024 1.552 0 3.174-.535 3.174-1.538v-.028c0-.073-.01-.145-.03-.217.088-.008.174-.013.256-.013.398 0 .69.1.85.145.08.022.156.033.224.033.36 0 .594-.27.65-.536.004-.026.006-.052.006-.077 0-.198-.1-.382-.27-.494.006-.023.01-.047.01-.07 0-.298-.315-.566-.87-.757-.568-.194-1.207-.281-1.818-.362-1.126-.148-1.848-.457-2.114-.914-.046-.08-.07-.166-.07-.254 0-.025.002-.05.007-.074.02-.1.065-.196.135-.288.084-.11.203-.22.35-.327.29-.208.632-.4.902-.59.42-.293.668-.616.737-.963a1.4 1.4 0 00.025-.261c0-.463-.2-.9-.587-1.303-.624-.642-1.673-.933-1.673-.933s.189-.36.461-.752c.163-.231.358-.524.492-.728.074-.113.116-.17.14-.198.017.017.07.092.184.258l.026.038c.467.685 1.06 1.062 1.677 1.062.133 0 .268-.019.401-.057l.01-.003c.213-.057.413-.082.593-.082.53 0 .832.252 1.11.226.124-.012.197-.128.234-.21.746-1.676 2.38-1.928 2.396-1.93.355-.048.65-.344.65-.72 0-.412-.358-.729-.754-.729-.081 0-.164.016-.246.047-.212.084-.512.13-.836.13-.59 0-1.114-.128-1.548-.356.081-.496.132-1.003.154-1.516.12-2.85-.81-5.445-2.644-7.424C17.46 1.108 14.853.006 12 .006z"/></svg>,
  }
  return <>{icons[platform.toLowerCase()] || <Sparkles size={20} />}</>
}

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [social, setSocial] = useState<SocialMedia[]>([])
  const [storeInfo, setStoreInfo] = useState({ name: 'Slime & Glow', tagline: 'أجمل السلايمات والفومات' })
  const [loading, setLoading] = useState(true)
  const addItem = useCartStore(s => s.addItem)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()
      const [
        { data: prods },
        { data: cats },
        { data: settings }
      ] = await Promise.all([
        supabase.from('products').select('*, category:categories(*)').eq('is_active', true).eq('is_featured', true).limit(6),
        supabase.from('categories').select('*').eq('is_active', true).order('sort_order'),
        supabase.from('site_settings').select('*').in('key', ['store_info', 'social_media']),
      ])
      setProducts(prods || [])
      setCategories(cats || [])
      if (settings) {
        const info = settings.find(s => s.key === 'store_info')?.value
        const socialData = settings.find(s => s.key === 'social_media')?.value
        if (info) setStoreInfo(info)
        if (socialData) setSocial(socialData)
      }
      setLoading(false)
    }
    fetchData()
  }, [])

  return (
    <div className="page-enter">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-16 px-4">
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full opacity-20"
              style={{
                width: `${60 + i * 30}px`,
                height: `${60 + i * 30}px`,
                background: i % 2 === 0 ? '#F9A8D4' : '#FBCFE8',
                left: `${10 + i * 15}%`,
                top: `${10 + (i % 3) * 25}%`,
              }}
              animate={{
                y: [0, -20, 0],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 3 + i * 0.5,
                repeat: Infinity,
                delay: i * 0.3,
              }}
            />
          ))}
        </div>

        <div className="max-w-4xl mx-auto text-center relative">
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', duration: 0.8 }}
            className="w-24 h-24 mx-auto mb-6 slime-blob flex items-center justify-center text-4xl"
            style={{ background: 'linear-gradient(135deg, #F9A8D4, #EC4899)' }}
          >
            ✨
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-4xl md:text-6xl font-black mb-4"
            style={{ color: 'var(--text)' }}
          >
            Slime & Glow
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-xl md:text-2xl font-semibold mb-2"
            style={{ color: 'var(--primary-dark)' }}
          >
            {storeInfo.tagline}
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-gray-500 mb-8 font-medium"
          >
            🚚 التوصيل داخل رفحاء فقط
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-3 justify-center"
          >
            <Link href="/products" className="btn-pink text-lg px-8 py-4">
              <Sparkles size={20} />
              تسوّقي الآن
            </Link>
            <Link href="/products" className="btn-outline text-lg px-8 py-4">
              استعرضي المنتجات
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="px-4 mb-10">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-black mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-sm"
                style={{ background: 'var(--primary-dark)' }}>
                📦
              </span>
              الأقسام
            </h2>
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
              <Link href="/products"
                className="flex-shrink-0 px-5 py-3 rounded-2xl font-bold text-sm glass-card hover:border-pink-400 transition-all">
                الكل ✨
              </Link>
              {categories.map((cat, i) => (
                <motion.div
                  key={cat.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Link
                    href={`/products?category=${cat.slug}`}
                    className="flex-shrink-0 flex items-center gap-2 px-5 py-3 rounded-2xl font-bold text-sm glass-card hover:border-pink-400 transition-all"
                  >
                    {cat.image_url && (
                      <img src={cat.image_url} alt={cat.name} className="w-6 h-6 rounded-full object-cover" />
                    )}
                    {cat.name}
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured Products */}
      <section className="px-4 mb-10">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-black flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-sm"
                style={{ background: 'var(--primary-dark)' }}>
                ⭐
              </span>
              منتجات مميزة
            </h2>
            <Link href="/products" className="flex items-center gap-1 text-pink-500 font-bold text-sm hover:gap-2 transition-all">
              عرض الكل <ChevronLeft size={16} />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="product-card h-64 animate-pulse bg-pink-50" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-20 glass-card">
              <div className="text-5xl mb-4">🛍️</div>
              <p className="text-gray-500 font-semibold">لا توجد منتجات بعد</p>
              <p className="text-sm text-gray-400 mt-1">سيتم إضافة المنتجات قريباً</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {products.map((product, i) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="product-card"
                >
                  <Link href={`/products/${product.id}`}>
                    <div className="relative h-44 bg-pink-50 overflow-hidden">
                      {product.images?.[0] ? (
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-5xl">🫧</div>
                      )}
                      {product.stock === 0 && (
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <span className="bg-white text-gray-800 font-bold px-3 py-1 rounded-full text-sm">نفذت الكمية</span>
                        </div>
                      )}
                      <div className="absolute top-2 right-2">
                        <span className="badge">✨ مميز</span>
                      </div>
                    </div>
                  </Link>
                  <div className="p-3">
                    <Link href={`/products/${product.id}`}>
                      <h3 className="font-bold text-sm mb-1 line-clamp-2">{product.name}</h3>
                    </Link>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-black text-lg" style={{ color: 'var(--primary-dark)' }}>
                        {product.price} ر.س
                      </span>
                      <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => {
                          if (product.stock === 0) return
                          addItem(product)
                          toast.success('أضيف للسلة! 🛒')
                        }}
                        disabled={product.stock === 0}
                        className="btn-pink !py-2 !px-4 !text-xs disabled:opacity-50"
                      >
                        أضف
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Social Media */}
      {social.length > 0 && (
        <section className="px-4 mb-10">
          <div className="max-w-6xl mx-auto">
            <div className="glass-card p-6 text-center">
              <h2 className="text-xl font-black mb-4">تابعينا على وسائل التواصل 💖</h2>
              <div className="flex flex-wrap gap-3 justify-center">
                {social.map((s: any) => (
                  <a
                    key={s.id}
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-5 py-3 rounded-2xl font-bold transition-all hover:scale-105"
                    style={{ background: 'var(--primary-dark)', color: 'white' }}
                  >
                    <SocialIcon platform={s.platform} />
                    {s.platform}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  )
}
