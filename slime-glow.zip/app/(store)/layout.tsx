import Navbar from '@/components/store/Navbar'
import MobileNav from '@/components/store/MobileNav'

export default function StoreLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="bubble-bg min-h-screen">
      <Navbar />
      <main className="pb-20 md:pb-0">
        {children}
      </main>
      <MobileNav />
    </div>
  )
}
