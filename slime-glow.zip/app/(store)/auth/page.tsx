'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { motion, AnimatePresence } from 'framer-motion'
import { Phone, Lock, Eye, EyeOff, Sparkles, UserPlus, LogIn } from 'lucide-react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useAuthStore } from '@/lib/store/auth'
import toast from 'react-hot-toast'

export default function AuthPage() {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const redirect = searchParams.get('redirect') || '/'
  const setUser = useAuthStore(s => s.setUser)

  const formatPhone = (p: string) => {
    const digits = p.replace(/\D/g, '')
    if (digits.startsWith('0')) return '+966' + digits.slice(1)
    if (digits.startsWith('966')) return '+' + digits
    if (digits.startsWith('5') && digits.length === 9) return '+966' + digits
    return digits
  }

  const handleSubmit = async () => {
    if (!phone.trim() || !password.trim()) {
      toast.error('ادخلي جميع البيانات')
      return
    }
    if (password.length < 6) {
      toast.error('كلمة المرور يجب أن تكون 6 أحرف على الأقل')
      return
    }

    setLoading(true)
    const supabase = createClient()
    const formattedPhone = formatPhone(phone)
    const email = `${formattedPhone.replace('+', '')}@slimeglow.sa`

    if (mode === 'register') {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { phone: formattedPhone, full_name: name } },
      })
      if (error) {
        toast.error(error.message === 'User already registered' ? 'هذا الرقم مسجل مسبقاً، سجّلي دخولك' : 'حدث خطأ، حاولي مجدداً')
        setLoading(false)
        return
      }

      if (data.user) {
        await supabase.from('profiles').upsert({
          id: data.user.id,
          phone: formattedPhone,
          full_name: name || null,
          role: 'customer',
        })
        const { data: profile } = await supabase.from('profiles').select('*').eq('id', data.user.id).single()
        if (profile) setUser(profile)
        toast.success('تم إنشاء الحساب بنجاح 🎉')
        router.push(redirect)
      }
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) {
        toast.error('رقم الجوال أو كلمة المرور غير صحيحة')
        setLoading(false)
        return
      }
      if (data.user) {
        const { data: profile } = await supabase.from('profiles').select('*').eq('id', data.user.id).single()
        if (profile) setUser(profile)
        toast.success('أهلاً بك! 💖')
        router.push(redirect)
      }
    }
    setLoading(false)
  }

  return (
    <div className="page-enter min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto mb-4 slime-blob flex items-center justify-center text-3xl"
            style={{ background: 'linear-gradient(135deg, #F9A8D4, #EC4899)' }}>
            ✨
          </div>
          <h1 className="text-3xl font-black">Slime & Glow</h1>
          <p className="text-gray-500 mt-1 font-medium">
            {mode === 'login' ? 'أهلاً بعودتك 💖' : 'انضمي إلينا 🌟'}
          </p>
        </div>

        {/* Mode tabs */}
        <div className="glass-card flex mb-6 p-1 rounded-2xl">
          <button
            onClick={() => setMode('login')}
            className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
              mode === 'login' ? 'text-white' : 'text-gray-500'
            }`}
            style={mode === 'login' ? { background: 'var(--primary-dark)' } : {}}
          >
            <LogIn size={16} />
            تسجيل دخول
          </button>
          <button
            onClick={() => setMode('register')}
            className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
              mode === 'register' ? 'text-white' : 'text-gray-500'
            }`}
            style={mode === 'register' ? { background: 'var(--primary-dark)' } : {}}
          >
            <UserPlus size={16} />
            حساب جديد
          </button>
        </div>

        <div className="glass-card p-6 space-y-4">
          <AnimatePresence mode="wait">
            {mode === 'register' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
              >
                <label className="block font-bold text-sm mb-1.5">الاسم (اختياري)</label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="اسمك"
                  className="input-pink"
                />
              </motion.div>
            )}
          </AnimatePresence>

          <div>
            <label className="block font-bold text-sm mb-1.5">رقم الجوال</label>
            <div className="relative">
              <Phone size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-pink-400" />
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="05xxxxxxxx"
                className="input-pink pr-12"
                dir="ltr"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-sm mb-1.5">كلمة المرور</label>
            <div className="relative">
              <Lock size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-pink-400" />
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••"
                className="input-pink pr-12 pl-12"
                onKeyDown={e => e.key === 'Enter' && handleSubmit()}
              />
              <button type="button" onClick={() => setShowPass(!showPass)}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleSubmit}
            disabled={loading}
            className="btn-pink w-full justify-center text-base py-3 disabled:opacity-60"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : mode === 'login' ? (
              <><LogIn size={18} /> دخول</>
            ) : (
              <><UserPlus size={18} /> إنشاء حساب</>
            )}
          </motion.button>
        </div>
      </motion.div>
    </div>
  )
}
