'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useAuthStore } from '@/lib/store/auth'
import { Order } from '@/types'
import { motion } from 'framer-motion'
import { Package, Clock, CheckCircle, XCircle, Truck, Upload } from 'lucide-react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { useRef } from 'react'

const statusMap: Record<string, { label: string; color: string; icon: any }> = {
  pending: { label: 'في الانتظار', color: 'text-yellow-600 bg-yellow-50', icon: Clock },
  preparing: { label: 'جاري التجهيز', color: 'text-blue-600 bg-blue-50', icon: Package },
  out_for_delivery: { label: 'في الطريق', color: 'text-purple-600 bg-purple-50', icon: Truck },
  delivered: { label: 'تم التسليم', color: 'text-green-600 bg-green-50', icon: CheckCircle },
  cancelled: { label: 'ملغي', color: 'text-red-600 bg-red-50', icon: XCircle },
}

const paymentStatusMap: Record<string, { label: string; color: string }> = {
  pending: { label: 'في انتظار التحويل', color: 'text-yellow-600' },
  receipt_uploaded: { label: 'تم رفع الإيصال', color: 'text-blue-600' },
  confirmed: { label: 'تم التأكيد ✓', color: 'text-green-600' },
  rejected: { label: 'مرفوض', color: 'text-red-600' },
}

export default function OrdersPage() {
  const user = useAuthStore(s => s.user)
  const router = useRouter()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [uploadingFor, setUploadingFor] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!user) { router.push('/auth'); return }
    fetchOrders()
  }, [user])

  const fetchOrders = async () => {
    const supabase = createClient()
    const { data } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', user?.id)
      .order('created_at', { ascending: false })
    setOrders(data || [])
    setLoading(false)
  }

  const handleReceiptUpload = async (orderId: string, file: File) => {
    if (file.size > 5 * 1024 * 1024) { toast.error('الملف أكبر من 5MB'); return }
    setUploadingFor(orderId)
    const supabase = createClient()
    const fileName = `${orderId}_${Date.now()}`
    const { error: uploadError } = await supabase.storage.from('receipts').upload(fileName, file)
    if (uploadError) { toast.error('فشل رفع الإيصال'); setUploadingFor(null); return }
    const url = supabase.storage.from('receipts').getPublicUrl(fileName).data.publicUrl
    await supabase.from('orders').update({ receipt_url: url, payment_status: 'receipt_uploaded' }).eq('id', orderId)
    toast.success('تم رفع الإيصال بنجاح ✓')
    fetchOrders()
    setUploadingFor(null)
  }

  if (!user) return null

  return (
    <div className="page-enter max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-black mb-8 flex items-center gap-3">
        <Package size={32} style={{ color: 'var(--primary-dark)' }} />
        طلباتي
      </h1>

      {loading ? (
        <div className="space-y-4">
          {[1,2,3].map(i => <div key={i} className="glass-card h-32 animate-pulse" />)}
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-20 glass-card">
          <div className="text-6xl mb-4">📦</div>
          <p className="font-bold text-xl mb-2">لا توجد طلبات بعد</p>
          <Link href="/products" className="btn-pink mt-4 inline-flex">تسوّقي الآن</Link>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order, i) => {
            const status = statusMap[order.order_status] || statusMap.pending
            const StatusIcon = status.icon
            const pStatus = paymentStatusMap[order.payment_status]

            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="glass-card p-5"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="font-black text-lg">{order.order_number}</p>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {new Date(order.created_at).toLocaleDateString('ar-SA', {
                        year: 'numeric', month: 'long', day: 'numeric',
                        hour: '2-digit', minute: '2-digit'
                      })}
                    </p>
                  </div>
                  <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-bold ${status.color}`}>
                    <StatusIcon size={14} />
                    {status.label}
                  </div>
                </div>

                {/* Items */}
                <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
                  {(order.items as any[]).map((item, j) => (
                    <div key={j} className="flex-shrink-0 text-center">
                      <div className="w-12 h-12 rounded-xl overflow-hidden bg-pink-50 mb-1">
                        {item.product_image
                          ? <img src={item.product_image} alt="" className="w-full h-full object-cover" />
                          : <div className="w-full h-full flex items-center justify-center">🫧</div>
                        }
                      </div>
                      <p className="text-xs font-bold w-14 truncate">{item.product_name}</p>
                      <p className="text-xs text-gray-400">×{item.quantity}</p>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between text-sm border-t border-pink-100 pt-3">
                  <div>
                    <span className="text-gray-500">الإجمالي: </span>
                    <span className="font-black text-lg" style={{ color: 'var(--primary-dark)' }}>{order.total} ر.س</span>
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-gray-400">{order.payment_method === 'transfer' ? 'تحويل بنكي' : 'كاش'}</p>
                    <p className={`text-xs font-bold ${pStatus?.color}`}>{pStatus?.label}</p>
                  </div>
                </div>

                {/* Upload receipt if transfer and pending */}
                {order.payment_method === 'transfer' && order.payment_status === 'pending' && (
                  <div className="mt-3">
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      ref={fileRef}
                      onChange={e => {
                        const file = e.target.files?.[0]
                        if (file) handleReceiptUpload(order.id, file)
                      }}
                    />
                    <button
                      onClick={() => { setUploadingFor(order.id); fileRef.current?.click() }}
                      className="btn-outline w-full justify-center !py-2 !text-sm"
                      disabled={uploadingFor === order.id}
                    >
                      {uploadingFor === order.id ? (
                        <div className="w-4 h-4 border-2 border-pink-500 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <><Upload size={14} /> ارفعي إيصال التحويل</>
                      )}
                    </button>
                  </div>
                )}

                {order.delivery_location && (
                  <a
                    href={`https://www.google.com/maps?q=${order.delivery_location.lat},${order.delivery_location.lng}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 mt-2 text-xs text-blue-500 hover:underline"
                  >
                    📍 موقع التوصيل
                  </a>
                )}
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
