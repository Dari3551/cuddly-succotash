import type { Metadata, Viewport } from 'next'
import { Tajawal } from 'next/font/google'
import './globals.css'
import { Toaster } from 'react-hot-toast'
import AuthProvider from '@/components/providers/AuthProvider'
import VisitTracker from '@/components/providers/VisitTracker'

const tajawal = Tajawal({
  subsets: ['arabic'],
  weight: ['300', '400', '500', '700', '800', '900'],
  variable: '--font-tajawal',
})

export const metadata: Metadata = {
  title: 'Slime & Glow - رفحاء',
  description: 'أجمل السلايمات والفومات في رفحاء',
  keywords: 'سلايم, فوم, رفحاء, slime, glow',
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
      </head>
      <body className={`${tajawal.variable} font-arabic`}>
        <AuthProvider>
          <VisitTracker />
          {children}
          <Toaster
            position="top-center"
            toastOptions={{
              style: {
                fontFamily: 'Tajawal, sans-serif',
                direction: 'rtl',
                background: '#fff',
                color: '#4A1942',
                border: '2px solid #F9A8D4',
                borderRadius: '16px',
                padding: '12px 20px',
              },
            }}
          />
        </AuthProvider>
      </body>
    </html>
  )
}
