'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Store, Truck, CreditCard, Palette, Share2, Plus, Trash2,
  Save, Check, ChevronDown, ChevronUp
} from 'lucide-react'
import toast from 'react-hot-toast'

const BANKS = [
  'بنك الراجحي', 'البنك الأهلي السعودي', 'بنك الرياض', 'البنك السعودي الفرنسي',
  'البنك العربي الوطني', 'بنك البلاد', 'بنك الجزيرة', 'بنك الإنماء',
  'مصرف الراجحي', 'بنك سامبا',
]

const PLATFORMS = [
  { value: 'tiktok', label: 'تيك توك', emoji: '🎵' },
  { value: 'instagram', label: 'انستغرام', emoji: '📸' },
  { value: 'snapchat', label: 'سناب شات', emoji: '👻' },
  { value: 'twitter', label: 'تويتر / X', emoji: '🐦' },
  { value: 'youtube', label: 'يوتيوب', emoji: '▶️' },
  { value: 'facebook', label: 'فيسبوك', emoji: '📘' },
]

const THEMES = [
  { name: 'وردي ناعم', primaryColor: '#F9A8D4', secondaryColor: '#FBCFE8', accentColor: '#EC4899', bgColor: '#FFF5F9', textColor: '#4A1942' },
  { name: 'ليلكي', primaryColor: '#DDD6FE', secondaryColor: '#EDE9FE', accentColor: '#7C3AED', bgColor: '#F9F7FF', textColor: '#2D1B69' },
  { name: 'أزرق', primaryColor: '#BAE6FD', secondaryColor: '#E0F2FE', accentColor: '#0284C7', bgColor: '#F0F9FF', textColor: '#0C2D48' },
  { name: 'أخضر', primaryColor: '#BBF7D0', secondaryColor: '#DCFCE7', accentColor: '#16A34A', bgColor: '#F0FFF4', textColor: '#14532D' },
  { name: 'برتقالي', primaryColor: '#FED7AA', secondaryColor: '#FFEDD5', accentColor: '#EA580C', bgColor: '#FFF7F0', textColor: '#431407' },
  { name: 'أحمر وردي', primaryColor: '#FECDD3', secondaryColor: '#FFE4E6', accentColor: '#E11D48', bgColor: '#FFF5F6', textColor: '#4C0519' },
]

type Section = 'store' | 'theme' | 'delivery' | 'payment' | 'social'

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Record<string, any>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [openSection, setOpenSection] = useState<Section>('store')
  const [socialItems, setSocialItems] = useState<any[]>([])

  useEffect(() => { fetchSettings() }, [])

  const fetchSettings = async () => {
    const supabase = createClient()
    const { data } = await supabase.from('site_settings').select('*')
    const map: Record<string, any> = {}
    data?.forEach(s => { map[s.key] = s.value })
    setSettings(map)
    setSocialItems(map.social_media || [])
    setLoading(false)
  }

  const saveSetting = async (key: string, value: any) => {
    setSaving(key)
    const supabase = createClient()
    await supabase.from('site_settings').upsert({ key, value, updated_at: new Date().toISOString() }, { onConflict: 'key' })
    setSettings(prev => ({ ...prev, [key]: value }))
    toast.success('تم الحفظ ✓')
    setSaving(null)

    // Apply theme live
    if (key === 'theme') {
      Object.entries(value).forEach(([k, v]) => {
        const cssVar = k === 'primaryColor' ? '--primary' :
          k === 'secondaryColor' ? '--secondary' :
          k === 'accentColor' ? '--accent' :
          k === 'bgColor' ? '--bg' :
          k === 'textColor' ? '--text' : null
        if (cssVar) document.documentElement.style.setProperty(cssVar, v as string)
      })
    }
  }

  const SectionHeader = ({ id, icon: Icon, title }: { id: Section, icon: any, title: string }) => (
    <button onClick={() => setOpenSection(openSection === id ? ('none' as Section) : id)}
      className="w-full flex items-center justify-between p-4 bg-white rounded-2xl border border-pink-100 shadow-sm hover:border-pink-300 transition-colors">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'var(--secondary)' }}>
          <Icon size={18} style={{ color: 'var(--primary-dark)' }} />
        </div>
        <span className="font-black">{title}</span>
      </div>
      {openSection === id ? <ChevronUp size={18} className="text-gray-400" /> : <ChevronDown size={18} className="text-gray-400" />}
    </button>
  )

  if (loading) return <div className="flex justify-center py-20"><div className="spinner" /></div>

  const storeInfo = settings.store_info || {}
  const theme = settings.theme || THEMES[0]
  const delivery = settings.delivery || {}
  const payment = settings.payment || { methods: ['transfer', 'cash'], bankName: '', accountName: '', accountNumber: '', iban: '' }

  return (
    <div className="space-y-3 max-w-2xl">
      {/* Store Info */}
      <SectionHeader id="store" icon={Store} title="معلومات المتجر" />
      <AnimatePresence>
        {openSection === 'store' && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden">
            <div className="bg-white rounded-2xl border border-pink-100 p-5 space-y-4">
              {[
                { key: 'name', label: 'اسم المتجر', placeholder: 'Slime & Glow' },
                { key: 'tagline', label: 'الشعار / الوصف', placeholder: 'أجمل السلايمات في رفحاء' },
                { key: 'phone', label: 'رقم الجوال', placeholder: '05xxxxxxxx' },
                { key: 'whatsapp', label: 'رقم واتساب', placeholder: '05xxxxxxxx' },
              ].map(({ key, label, placeholder }) => (
                <div key={key}>
                  <label className="block font-bold text-sm mb-1.5">{label}</label>
                  <input
                    value={storeInfo[key] || ''}
                    onChange={e => setSettings(prev => ({ ...prev, store_info: { ...storeInfo, [key]: e.target.value } }))}
                    placeholder={placeholder}
                    className="input-pink"
                    dir={key === 'phone' || key === 'whatsapp' ? 'ltr' : 'rtl'}
                  />
                </div>
              ))}
              <button onClick={() => saveSetting('store_info', storeInfo)} disabled={saving === 'store_info'}
                className="btn-pink w-full justify-center">
                {saving === 'store_info' ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Save size={16} /> حفظ</>}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Theme */}
      <SectionHeader id="theme" icon={Palette} title="الألوان والمظهر" />
      <AnimatePresence>
        {openSection === 'theme' && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden">
            <div className="bg-white rounded-2xl border border-pink-100 p-5 space-y-4">
              <p className="font-bold text-sm text-gray-500">اختاري ثيماً جاهزاً:</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {THEMES.map((t, i) => (
                  <button key={i} onClick={() => {
                    setSettings(prev => ({ ...prev, theme: t }))
                    saveSetting('theme', t)
                  }}
                    className={`p-3 rounded-xl border-2 transition-all text-right ${
                      theme.accentColor === t.accentColor ? 'border-pink-500 shadow-md' : 'border-gray-200 hover:border-pink-300'
                    }`}
                    style={{ background: t.bgColor }}>
                    <div className="flex gap-1 mb-2">
                      <div className="w-5 h-5 rounded-full" style={{ background: t.primaryColor }} />
                      <div className="w-5 h-5 rounded-full" style={{ background: t.accentColor }} />
                      <div className="w-5 h-5 rounded-full" style={{ background: t.secondaryColor }} />
                    </div>
                    <p className="font-bold text-xs" style={{ color: t.textColor }}>{t.name}</p>
                    {theme.accentColor === t.accentColor && <Check size={12} className="text-pink-600 mt-1" />}
                  </button>
                ))}
              </div>
              <p className="font-bold text-sm text-gray-500 pt-2">أو خصّصي الألوان:</p>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { key: 'primaryColor', label: 'اللون الرئيسي' },
                  { key: 'accentColor', label: 'لون التمييز' },
                  { key: 'bgColor', label: 'خلفية الموقع' },
                  { key: 'textColor', label: 'لون النص' },
                ].map(({ key, label }) => (
                  <div key={key} className="flex items-center gap-2">
                    <input type="color" value={theme[key] || '#EC4899'}
                      onChange={e => setSettings(prev => ({ ...prev, theme: { ...theme, [key]: e.target.value } }))}
                      className="w-10 h-10 rounded-xl border border-gray-200 cursor-pointer p-1" />
                    <label className="font-bold text-sm">{label}</label>
                  </div>
                ))}
              </div>
              <button onClick={() => saveSetting('theme', theme)} disabled={saving === 'theme'}
                className="btn-pink w-full justify-center">
                {saving === 'theme' ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Save size={16} /> حفظ</>}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delivery */}
      <SectionHeader id="delivery" icon={Truck} title="إعدادات التوصيل" />
      <AnimatePresence>
        {openSection === 'delivery' && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden">
            <div className="bg-white rounded-2xl border border-pink-100 p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-sm mb-1.5">رسوم التوصيل (ر.س)</label>
                  <input type="number" value={delivery.fee || 10}
                    onChange={e => setSettings(prev => ({ ...prev, delivery: { ...delivery, fee: +e.target.value } }))}
                    className="input-pink" min="0" />
                </div>
                <div>
                  <label className="block font-bold text-sm mb-1.5">توصيل مجاني فوق (ر.س)</label>
                  <input type="number" value={delivery.freeDeliveryAbove || 100}
                    onChange={e => setSettings(prev => ({ ...prev, delivery: { ...delivery, freeDeliveryAbove: +e.target.value } }))}
                    className="input-pink" min="0" />
                </div>
              </div>
              <div>
                <label className="block font-bold text-sm mb-1.5">الوقت المتوقع للتوصيل</label>
                <input value={delivery.estimatedTime || '30-60 دقيقة'}
                  onChange={e => setSettings(prev => ({ ...prev, delivery: { ...delivery, estimatedTime: e.target.value } }))}
                  placeholder="30-60 دقيقة" className="input-pink" />
              </div>
              <button onClick={() => saveSetting('delivery', delivery)} disabled={saving === 'delivery'}
                className="btn-pink w-full justify-center">
                {saving === 'delivery' ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Save size={16} /> حفظ</>}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Payment */}
      <SectionHeader id="payment" icon={CreditCard} title="إعدادات الدفع" />
      <AnimatePresence>
        {openSection === 'payment' && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden">
            <div className="bg-white rounded-2xl border border-pink-100 p-5 space-y-4">
              <div>
                <label className="block font-bold text-sm mb-2">طرق الدفع المتاحة</label>
                <div className="flex gap-3">
                  {[{ v: 'transfer', l: 'تحويل بنكي 🏦' }, { v: 'cash', l: 'كاش 💵' }].map(({ v, l }) => {
                    const methods = payment.methods || []
                    const isOn = methods.includes(v)
                    return (
                      <button key={v} onClick={() => {
                        const newMethods = isOn ? methods.filter((m: string) => m !== v) : [...methods, v]
                        setSettings(prev => ({ ...prev, payment: { ...payment, methods: newMethods } }))
                      }}
                        className={`px-4 py-2 rounded-xl font-bold text-sm border-2 transition-all ${isOn ? 'border-pink-500 bg-pink-50 text-pink-600' : 'border-gray-200'}`}>
                        {l}
                      </button>
                    )
                  })}
                </div>
              </div>
              <div>
                <label className="block font-bold text-sm mb-1.5">البنك</label>
                <select value={payment.bankName || ''}
                  onChange={e => setSettings(prev => ({ ...prev, payment: { ...payment, bankName: e.target.value } }))}
                  className="input-pink">
                  <option value="">اختر البنك</option>
                  {BANKS.map(b => <option key={b} value={b}>{b}</option>)}
                </select>
              </div>
              {[
                { key: 'accountName', label: 'اسم صاحب الحساب' },
                { key: 'iban', label: 'رقم الآيبان (IBAN)', dir: 'ltr' },
                { key: 'accountNumber', label: 'رقم الحساب', dir: 'ltr' },
              ].map(({ key, label, dir }) => (
                <div key={key}>
                  <label className="block font-bold text-sm mb-1.5">{label}</label>
                  <input value={payment[key] || ''}
                    onChange={e => setSettings(prev => ({ ...prev, payment: { ...payment, [key]: e.target.value } }))}
                    placeholder={label} className="input-pink" dir={dir as any || 'rtl'} />
                </div>
              ))}
              <button onClick={() => saveSetting('payment', payment)} disabled={saving === 'payment'}
                className="btn-pink w-full justify-center">
                {saving === 'payment' ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Save size={16} /> حفظ</>}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Social Media */}
      <SectionHeader id="social" icon={Share2} title="حسابات التواصل الاجتماعي" />
      <AnimatePresence>
        {openSection === 'social' && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden">
            <div className="bg-white rounded-2xl border border-pink-100 p-5 space-y-4">
              {socialItems.map((item, i) => (
                <div key={i} className="flex gap-2 items-end">
                  <div className="flex-1 space-y-2">
                    <select value={item.platform}
                      onChange={e => setSocialItems(prev => prev.map((s, j) => j === i ? { ...s, platform: e.target.value } : s))}
                      className="input-pink !py-2">
                      {PLATFORMS.map(p => <option key={p.value} value={p.value}>{p.emoji} {p.label}</option>)}
                    </select>
                    <input value={item.url}
                      onChange={e => setSocialItems(prev => prev.map((s, j) => j === i ? { ...s, url: e.target.value } : s))}
                      placeholder="https://tiktok.com/@username" className="input-pink !py-2" dir="ltr" />
                  </div>
                  <button onClick={() => setSocialItems(prev => prev.filter((_, j) => j !== i))}
                    className="px-3 py-2 bg-red-50 text-red-500 rounded-xl hover:bg-red-100 transition-colors mb-0.5">
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
              <button onClick={() => setSocialItems(prev => [...prev, { id: Date.now().toString(), platform: 'tiktok', url: '' }])}
                className="btn-outline w-full justify-center !py-2.5">
                <Plus size={16} /> إضافة حساب
              </button>
              <button onClick={() => saveSetting('social_media', socialItems)} disabled={saving === 'social_media'}
                className="btn-pink w-full justify-center">
                {saving === 'social_media' ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Save size={16} /> حفظ</>}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
