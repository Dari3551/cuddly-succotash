'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { DiscountCode } from '@/types'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Trash2, Tag, X, Copy } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminDiscountsPage() {
  const [codes, setCodes] = useState<DiscountCode[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    code: '', discount_type: 'percentage', discount_value: '', min_order_amount: '0',
    max_uses: '', expires_at: '', is_active: true,
  })

  useEffect(() => { fetchCodes() }, [])

  const fetchCodes = async () => {
    const supabase = createClient()
    const { data } = await supabase.from('discount_codes').select('*').order('created_at', { ascending: false })
    setCodes(data || [])
    setLoading(false)
  }

  const genCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    const code = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    setForm(f => ({ ...f, code }))
  }

  const handleSave = async () => {
    if (!form.code.trim() || !form.discount_value) { toast.error('الكود والقيمة مطلوبان'); return }
    setSaving(true)
    const supabase = createClient()
    await supabase.from('discount_codes').insert({
      code: form.code.toUpperCase().trim(),
      discount_type: form.discount_type,
      discount_value: parseFloat(form.discount_value),
      min_order_amount: parseFloat(form.min_order_amount) || 0,
      max_uses: form.max_uses ? parseInt(form.max_uses) : null,
      expires_at: form.expires_at || null,
      is_active: form.is_active,
    })
    toast.success('تم إضافة الكود ✓')
    setSaving(false)
    setShowForm(false)
    setForm({ code: '', discount_type: 'percentage', discount_value: '', min_order_amount: '0', max_uses: '', expires_at: '', is_active: true })
    fetchCodes()
  }

  const toggleActive = async (id: string, current: boolean) => {
    const supabase = createClient()
    await supabase.from('discount_codes').update({ is_active: !current }).eq('id', id)
    setCodes(prev => prev.map(c => c.id === id ? { ...c, is_active: !current } : c))
  }

  const handleDelete = async (id: string) => {
    if (!confirm('حذف هذا الكود؟')) return
    const supabase = createClient()
    await supabase.from('discount_codes').delete().eq('id', id)
    toast.success('تم الحذف')
    fetchCodes()
  }

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code)
    toast.success('تم النسخ ✓')
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="font-black text-xl">أكواد الخصم ({codes.length})</h2>
        <button onClick={() => setShowForm(true)} className="btn-pink !py-2.5">
          <Plus size={18} /> إضافة كود
        </button>
      </div>

      {/* Form Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={e => e.target === e.currentTarget && setShowForm(false)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }}
              className="bg-white rounded-3xl p-6 w-full max-w-md">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-black text-xl">إضافة كود خصم</h3>
                <button onClick={() => setShowForm(false)} className="w-9 h-9 rounded-xl bg-gray-100 flex items-center justify-center"><X size={18} /></button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block font-bold text-sm mb-1.5">الكود *</label>
                  <div className="flex gap-2">
                    <input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))}
                      placeholder="SLIME20" className="input-pink flex-1" dir="ltr" />
                    <button onClick={genCode} className="btn-outline !py-2 !px-4 !text-sm">توليد</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-sm mb-1.5">نوع الخصم</label>
                    <select value={form.discount_type} onChange={e => setForm(f => ({ ...f, discount_type: e.target.value }))} className="input-pink">
                      <option value="percentage">نسبة مئوية %</option>
                      <option value="fixed">مبلغ ثابت ر.س</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-sm mb-1.5">القيمة *</label>
                    <input type="number" value={form.discount_value} onChange={e => setForm(f => ({ ...f, discount_value: e.target.value }))}
                      placeholder={form.discount_type === 'percentage' ? '20' : '10'} className="input-pink" min="0" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-sm mb-1.5">حد أدنى للطلب</label>
                    <input type="number" value={form.min_order_amount} onChange={e => setForm(f => ({ ...f, min_order_amount: e.target.value }))}
                      className="input-pink" min="0" />
                  </div>
                  <div>
                    <label className="block font-bold text-sm mb-1.5">حد الاستخدام</label>
                    <input type="number" value={form.max_uses} onChange={e => setForm(f => ({ ...f, max_uses: e.target.value }))}
                      placeholder="غير محدود" className="input-pink" min="1" />
                  </div>
                </div>
                <div>
                  <label className="block font-bold text-sm mb-1.5">تاريخ الانتهاء (اختياري)</label>
                  <input type="datetime-local" value={form.expires_at} onChange={e => setForm(f => ({ ...f, expires_at: e.target.value }))}
                    className="input-pink" dir="ltr" />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setShowForm(false)} className="btn-outline flex-1 justify-center">إلغاء</button>
                <button onClick={handleSave} disabled={saving} className="btn-pink flex-1 justify-center disabled:opacity-60">
                  {saving ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : 'حفظ'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-white rounded-2xl animate-pulse" />)}</div>
      ) : codes.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl">
          <Tag size={40} className="mx-auto mb-3 text-pink-300" />
          <p className="font-bold text-gray-400 mb-3">لا توجد أكواد</p>
          <button onClick={() => setShowForm(true)} className="btn-pink"><Plus size={16} /> أضف أول كود</button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3">
          {codes.map((code, i) => {
            const isExpired = code.expires_at ? new Date(code.expires_at) < new Date() : false
            const isExhausted = code.max_uses ? code.used_count >= code.max_uses : false
            return (
              <motion.div key={code.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className={`bg-white rounded-2xl border p-4 shadow-sm ${!code.is_active || isExpired || isExhausted ? 'opacity-60 border-gray-200' : 'border-pink-100'}`}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'var(--primary-dark)' }}>
                      <Tag size={14} className="text-white" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-black text-lg" dir="ltr">{code.code}</span>
                        <button onClick={() => copyCode(code.code)} className="text-gray-400 hover:text-pink-500">
                          <Copy size={13} />
                        </button>
                      </div>
                      <p className="text-xs text-gray-400">
                        {code.discount_type === 'percentage' ? `${code.discount_value}%` : `${code.discount_value} ر.س`} خصم
                        {code.min_order_amount > 0 && ` • حد أدنى ${code.min_order_amount} ر.س`}
                      </p>
                    </div>
                  </div>
                  <button onClick={() => handleDelete(code.id)} className="text-red-400 hover:text-red-600 p-1">
                    <Trash2 size={15} />
                  </button>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <div className="flex gap-2">
                    <span className="text-gray-400">استُخدم: {code.used_count}{code.max_uses ? `/${code.max_uses}` : ''}</span>
                    {isExpired && <span className="text-red-500 font-bold">منتهي</span>}
                    {isExhausted && <span className="text-orange-500 font-bold">استُنفذ</span>}
                    {code.expires_at && !isExpired && (
                      <span className="text-gray-400">ينتهي: {new Date(code.expires_at).toLocaleDateString('ar-SA')}</span>
                    )}
                  </div>
                  <button onClick={() => toggleActive(code.id, code.is_active)}
                    className={`font-bold px-2.5 py-1 rounded-lg transition-colors ${code.is_active ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                    {code.is_active ? 'مفعّل' : 'معطّل'}
                  </button>
                </div>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
