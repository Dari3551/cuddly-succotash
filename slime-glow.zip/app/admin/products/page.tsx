'use client'
import { useEffect, useState, useRef } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Product, Category } from '@/types'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Pencil, Trash2, Upload, X, Star, StarOff, Eye, EyeOff, ImagePlus } from 'lucide-react'
import toast from 'react-hot-toast'

interface ProductForm {
  name: string
  description: string
  price: string
  stock: string
  category_id: string
  is_active: boolean
  is_featured: boolean
  images: string[]
}

const defaultForm: ProductForm = {
  name: '', description: '', price: '', stock: '0',
  category_id: '', is_active: true, is_featured: false, images: [],
}

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState<ProductForm>(defaultForm)
  const [saving, setSaving] = useState(false)
  const [uploadingImages, setUploadingImages] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => { fetchData() }, [])

  const fetchData = async () => {
    const supabase = createClient()
    const [{ data: prods }, { data: cats }] = await Promise.all([
      supabase.from('products').select('*, category:categories(*)').order('created_at', { ascending: false }),
      supabase.from('categories').select('*').eq('is_active', true).order('sort_order'),
    ])
    setProducts(prods || [])
    setCategories(cats || [])
    setLoading(false)
  }

  const openEdit = (product: Product) => {
    setForm({
      name: product.name,
      description: product.description || '',
      price: product.price.toString(),
      stock: product.stock.toString(),
      category_id: product.category_id || '',
      is_active: product.is_active,
      is_featured: product.is_featured,
      images: product.images || [],
    })
    setEditingId(product.id)
    setShowForm(true)
  }

  const handleImageUpload = async (files: FileList) => {
    setUploadingImages(true)
    const supabase = createClient()
    const newUrls: string[] = []

    for (const file of Array.from(files)) {
      if (file.size > 10 * 1024 * 1024) { toast.error(`${file.name} أكبر من 10MB`); continue }
      const path = `products/${Date.now()}_${file.name.replace(/\s/g, '_')}`
      const { error } = await supabase.storage.from('products').upload(path, file)
      if (!error) {
        const url = supabase.storage.from('products').getPublicUrl(path).data.publicUrl
        newUrls.push(url)
      }
    }

    setForm(f => ({ ...f, images: [...f.images, ...newUrls] }))
    setUploadingImages(false)
    if (newUrls.length > 0) toast.success(`تم رفع ${newUrls.length} صورة ✓`)
  }

  const removeImage = (idx: number) => {
    setForm(f => ({ ...f, images: f.images.filter((_, i) => i !== idx) }))
  }

  const handleSave = async () => {
    if (!form.name.trim() || !form.price) { toast.error('اسم المنتج والسعر مطلوبان'); return }
    setSaving(true)
    const supabase = createClient()

    const payload = {
      name: form.name.trim(),
      description: form.description.trim() || null,
      price: parseFloat(form.price),
      stock: parseInt(form.stock) || 0,
      category_id: form.category_id || null,
      is_active: form.is_active,
      is_featured: form.is_featured,
      images: form.images,
    }

    if (editingId) {
      const { error } = await supabase.from('products').update(payload).eq('id', editingId)
      if (error) { toast.error('حدث خطأ'); setSaving(false); return }
      toast.success('تم تحديث المنتج ✓')
    } else {
      const { error } = await supabase.from('products').insert(payload)
      if (error) { toast.error('حدث خطأ'); setSaving(false); return }
      toast.success('تم إضافة المنتج ✓')
    }

    setSaving(false)
    setShowForm(false)
    setEditingId(null)
    setForm(defaultForm)
    fetchData()
  }

  const handleDelete = async (id: string) => {
    if (!confirm('هل تريدين حذف هذا المنتج؟')) return
    const supabase = createClient()
    await supabase.from('products').delete().eq('id', id)
    toast.success('تم الحذف')
    fetchData()
  }

  const toggleActive = async (id: string, current: boolean) => {
    const supabase = createClient()
    await supabase.from('products').update({ is_active: !current }).eq('id', id)
    setProducts(prev => prev.map(p => p.id === id ? { ...p, is_active: !current } : p))
  }

  const toggleFeatured = async (id: string, current: boolean) => {
    const supabase = createClient()
    await supabase.from('products').update({ is_featured: !current }).eq('id', id)
    setProducts(prev => prev.map(p => p.id === id ? { ...p, is_featured: !current } : p))
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="font-black text-xl">المنتجات ({products.length})</h2>
        <button onClick={() => { setForm(defaultForm); setEditingId(null); setShowForm(true) }}
          className="btn-pink !py-2.5">
          <Plus size={18} /> إضافة منتج
        </button>
      </div>

      {/* Product Form Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={e => e.target === e.currentTarget && setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl p-6 w-full max-w-xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-black text-xl">{editingId ? 'تعديل المنتج' : 'إضافة منتج جديد'}</h3>
                <button onClick={() => setShowForm(false)}
                  className="w-9 h-9 rounded-xl bg-gray-100 flex items-center justify-center hover:bg-gray-200">
                  <X size={18} />
                </button>
              </div>

              <div className="space-y-4">
                {/* Images */}
                <div>
                  <label className="block font-bold text-sm mb-2">الصور</label>
                  <input ref={fileRef} type="file" accept="image/*" multiple className="hidden"
                    onChange={e => e.target.files && handleImageUpload(e.target.files)} />
                  <div className="flex gap-2 flex-wrap mb-2">
                    {form.images.map((img, i) => (
                      <div key={i} className="relative w-20 h-20">
                        <img src={img} alt="" className="w-full h-full object-cover rounded-xl border border-pink-200" />
                        <button onClick={() => removeImage(i)}
                          className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs font-bold">×</button>
                      </div>
                    ))}
                    <button onClick={() => fileRef.current?.click()}
                      disabled={uploadingImages}
                      className="w-20 h-20 border-2 border-dashed border-pink-300 rounded-xl flex flex-col items-center justify-center gap-1 hover:bg-pink-50 transition-colors">
                      {uploadingImages ? (
                        <div className="w-5 h-5 border-2 border-pink-500 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <><ImagePlus size={18} className="text-pink-400" /><span className="text-xs text-pink-400">رفع</span></>
                      )}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-sm mb-1.5">اسم المنتج *</label>
                  <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="مثال: سلايم الفراولة" className="input-pink" />
                </div>

                <div>
                  <label className="block font-bold text-sm mb-1.5">الوصف</label>
                  <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                    placeholder="وصف المنتج..." className="input-pink resize-none h-20" />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-sm mb-1.5">السعر (ر.س) *</label>
                    <input type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))}
                      placeholder="0.00" className="input-pink" min="0" step="0.5" />
                  </div>
                  <div>
                    <label className="block font-bold text-sm mb-1.5">المخزون</label>
                    <input type="number" value={form.stock} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))}
                      placeholder="0" className="input-pink" min="0" />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-sm mb-1.5">القسم</label>
                  <select value={form.category_id} onChange={e => setForm(f => ({ ...f, category_id: e.target.value }))}
                    className="input-pink">
                    <option value="">بدون قسم</option>
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>

                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <div onClick={() => setForm(f => ({ ...f, is_active: !f.is_active }))}
                      className={`w-12 h-6 rounded-full transition-colors relative ${form.is_active ? 'bg-pink-500' : 'bg-gray-300'}`}>
                      <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.is_active ? 'translate-x-6 right-0.5' : 'right-0.5'}`} />
                    </div>
                    <span className="font-bold text-sm">مفعّل</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <div onClick={() => setForm(f => ({ ...f, is_featured: !f.is_featured }))}
                      className={`w-12 h-6 rounded-full transition-colors relative ${form.is_featured ? 'bg-pink-500' : 'bg-gray-300'}`}>
                      <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.is_featured ? 'translate-x-6 right-0.5' : 'right-0.5'}`} />
                    </div>
                    <span className="font-bold text-sm">مميز</span>
                  </label>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button onClick={() => setShowForm(false)} className="btn-outline flex-1 justify-center">إلغاء</button>
                <button onClick={handleSave} disabled={saving} className="btn-pink flex-1 justify-center disabled:opacity-60">
                  {saving ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : 'حفظ'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Products List */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1,2,3,4,5,6].map(i => <div key={i} className="h-52 bg-white rounded-2xl animate-pulse" />)}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl">
          <div className="text-5xl mb-3">📦</div>
          <p className="font-bold text-gray-400 mb-3">لا توجد منتجات</p>
          <button onClick={() => setShowForm(true)} className="btn-pink"><Plus size={16} /> أضف أول منتج</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((product, i) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className={`bg-white rounded-2xl border overflow-hidden shadow-sm transition-all ${
                product.is_active ? 'border-pink-100' : 'border-gray-200 opacity-60'
              }`}
            >
              <div className="relative h-40 bg-pink-50">
                {product.images?.[0] ? (
                  <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-5xl">🫧</div>
                )}
                <div className="absolute top-2 right-2 flex gap-1.5">
                  {product.is_featured && <span className="badge text-xs">⭐ مميز</span>}
                  {!product.is_active && <span className="bg-gray-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">مخفي</span>}
                </div>
                {product.images?.length > 1 && (
                  <div className="absolute bottom-2 left-2 bg-black/50 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                    {product.images.length} صور
                  </div>
                )}
              </div>
              <div className="p-3">
                <h3 className="font-black text-sm mb-1 line-clamp-1">{product.name}</h3>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-black text-pink-600">{product.price} ر.س</span>
                  <span className="text-xs text-gray-400">مخزون: {product.stock}</span>
                </div>
                <div className="flex gap-1.5">
                  <button onClick={() => openEdit(product)}
                    className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100 transition-colors">
                    <Pencil size={12} /> تعديل
                  </button>
                  <button onClick={() => toggleFeatured(product.id, product.is_featured)}
                    className="px-2.5 py-1.5 bg-yellow-50 text-yellow-600 rounded-xl hover:bg-yellow-100 transition-colors">
                    {product.is_featured ? <Star size={14} fill="currentColor" /> : <StarOff size={14} />}
                  </button>
                  <button onClick={() => toggleActive(product.id, product.is_active)}
                    className="px-2.5 py-1.5 bg-gray-50 text-gray-600 rounded-xl hover:bg-gray-100 transition-colors">
                    {product.is_active ? <Eye size={14} /> : <EyeOff size={14} />}
                  </button>
                  <button onClick={() => handleDelete(product.id)}
                    className="px-2.5 py-1.5 bg-red-50 text-red-500 rounded-xl hover:bg-red-100 transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
