'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, Filter, MessageCircle, MapPin, CheckCircle, Eye, Upload, ChevronDown } from 'lucide-react'
import toast from 'react-hot-toast'

const orderStatuses = [
  { value: 'pending', label: 'معلق', color: 'text-yellow-600 bg-yellow-50 border-yellow-200' },
  { value: 'preparing', label: 'جاري التجهيز', color: 'text-blue-600 bg-blue-50 border-blue-200' },
  { value: 'out_for_delivery', label: 'في الطريق', color: 'text-purple-600 bg-purple-50 border-purple-200' },
  { value: 'delivered', label: 'مُسلَّم', color: 'text-green-600 bg-green-50 border-green-200' },
  { value: 'cancelled', label: 'ملغي', color: 'text-red-600 bg-red-50 border-red-200' },
]

const paymentStatuses = [
  { value: 'pending', label: 'لم يُحوَّل' },
  { value: 'receipt_uploaded', label: 'رُفع إيصال' },
  { value: 'confirmed', label: 'مؤكد ✓' },
  { value: 'rejected', label: 'مرفوض' },
]

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null)

  useEffect(() => { fetchOrders() }, [])

  const fetchOrders = async () => {
    const supabase = createClient()
    const { data } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false })
    setOrders(data || [])
    setLoading(false)
  }

  const updateOrderStatus = async (orderId: string, status: string) => {
    const supabase = createClient()
    await supabase.from('orders').update({ order_status: status }).eq('id', orderId)
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, order_status: status } : o))
    toast.success('تم تحديث حالة الطلب ✓')

    // Send WhatsApp if status = preparing
    if (status === 'preparing') {
      const order = orders.find(o => o.id === orderId)
      if (order?.customer_phone) {
        const msg = encodeURIComponent(`✨ مرحباً! طلبك رقم ${order.order_number} من Slime & Glow جاري تجهيزه الآن 🎀`)
        window.open(`https://wa.me/${order.customer_phone.replace('+', '')}?text=${msg}`, '_blank')
      }
    }
  }

  const confirmPayment = async (orderId: string) => {
    const supabase = createClient()
    await supabase.from('orders').update({ payment_status: 'confirmed' }).eq('id', orderId)
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, payment_status: 'confirmed' } : o))
    toast.success('تم تأكيد الدفع ✓')

    const order = orders.find(o => o.id === orderId)
    if (order?.customer_phone) {
      const msg = encodeURIComponent(`✨ أهلاً! تم تأكيد دفعك لطلب رقم ${order.order_number} من Slime & Glow. جاري تجهيز طلبك 🎀`)
      window.open(`https://wa.me/${order.customer_phone.replace('+', '')}?text=${msg}`, '_blank')
    }
    fetchOrders()
  }

  const openWhatsApp = (phone: string, orderNum: string) => {
    const msg = encodeURIComponent(`✨ مرحباً! بخصوص طلبك رقم ${orderNum} من Slime & Glow`)
    window.open(`https://wa.me/${phone.replace('+', '')}?text=${msg}`, '_blank')
  }

  const filtered = orders.filter(o => {
    const matchSearch = o.order_number?.includes(search) || o.customer_phone?.includes(search)
    const matchStatus = filterStatus === 'all' || o.order_status === filterStatus
    return matchSearch && matchStatus
  })

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="ابحث برقم الطلب أو الجوال..."
            className="input-pink pr-10 !py-2.5" />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setFilterStatus('all')}
            className={`px-3 py-2 rounded-xl text-sm font-bold border transition-all ${filterStatus === 'all' ? 'bg-pink-600 text-white border-pink-600' : 'border-gray-200 hover:border-pink-300'}`}>
            الكل ({orders.length})
          </button>
          {orderStatuses.slice(0, 3).map(s => (
            <button key={s.value} onClick={() => setFilterStatus(s.value)}
              className={`px-3 py-2 rounded-xl text-sm font-bold border transition-all ${filterStatus === s.value ? 'bg-pink-600 text-white border-pink-600' : 'border-gray-200'}`}>
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">{[1,2,3,4].map(i => <div key={i} className="h-24 bg-white rounded-2xl animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl">
          <div className="text-5xl mb-3">📦</div>
          <p className="font-bold text-gray-400">لا توجد طلبات</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((order, i) => {
            const statusInfo = orderStatuses.find(s => s.value === order.order_status)
            const isExpanded = expandedOrder === order.id
            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="bg-white rounded-2xl border border-pink-100 overflow-hidden shadow-sm"
              >
                {/* Header */}
                <div className="p-4 flex items-start gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-black text-sm">{order.order_number}</span>
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${statusInfo?.color}`}>
                        {statusInfo?.label}
                      </span>
                      {order.payment_method === 'transfer' && (
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-lg ${
                          order.payment_status === 'confirmed' ? 'bg-green-50 text-green-600' :
                          order.payment_status === 'receipt_uploaded' ? 'bg-blue-50 text-blue-600' :
                          'bg-yellow-50 text-yellow-600'
                        }`}>
                          {paymentStatuses.find(p => p.value === order.payment_status)?.label}
                        </span>
                      )}
                    </div>
                    <p className="text-gray-500 text-xs mt-1">
                      {order.customer_phone} • {order.customer_name} •{' '}
                      {new Date(order.created_at).toLocaleDateString('ar-SA', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  <div className="text-left flex-shrink-0">
                    <p className="font-black text-lg text-pink-600">{order.total} ر.س</p>
                    <p className="text-xs text-gray-400">{order.payment_method === 'transfer' ? 'تحويل' : 'كاش'}</p>
                  </div>
                  <button onClick={() => setExpandedOrder(isExpanded ? null : order.id)}
                    className="p-2 rounded-xl hover:bg-pink-50 transition-colors">
                    <ChevronDown size={18} className={`transition-transform ${isExpanded ? 'rotate-180' : ''}`} style={{ color: 'var(--primary-dark)' }} />
                  </button>
                </div>

                {/* Actions row */}
                <div className="px-4 pb-3 flex gap-2 flex-wrap">
                  {/* Status selector */}
                  <select
                    value={order.order_status}
                    onChange={e => updateOrderStatus(order.id, e.target.value)}
                    className="text-xs font-bold border border-pink-200 rounded-xl px-3 py-1.5 bg-white cursor-pointer focus:outline-none focus:border-pink-500"
                  >
                    {orderStatuses.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>

                  {/* WhatsApp */}
                  <button
                    onClick={() => openWhatsApp(order.customer_phone, order.order_number)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 text-green-600 rounded-xl text-xs font-bold hover:bg-green-100 transition-colors border border-green-200"
                  >
                    <MessageCircle size={13} />
                    واتساب
                  </button>

                  {/* Map location */}
                  {order.delivery_location && (
                    <a
                      href={`https://www.google.com/maps?q=${order.delivery_location.lat},${order.delivery_location.lng}`}
                      target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100 transition-colors border border-blue-200"
                    >
                      <MapPin size={13} />
                      الموقع
                    </a>
                  )}

                  {/* Confirm payment */}
                  {order.payment_method === 'transfer' && order.payment_status === 'receipt_uploaded' && (
                    <button
                      onClick={() => confirmPayment(order.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-pink-600 text-white rounded-xl text-xs font-bold hover:bg-pink-700 transition-colors"
                    >
                      <CheckCircle size={13} />
                      تأكيد الدفع
                    </button>
                  )}
                </div>

                {/* Expanded details */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="border-t border-pink-100 overflow-hidden"
                    >
                      <div className="p-4 bg-pink-50/50 space-y-4">
                        {/* Items */}
                        <div>
                          <p className="font-black text-sm mb-2">المنتجات:</p>
                          <div className="flex gap-3 flex-wrap">
                            {(order.items as any[]).map((item: any, j: number) => (
                              <div key={j} className="flex items-center gap-2 bg-white rounded-xl px-3 py-2">
                                {item.product_image && (
                                  <img src={item.product_image} alt="" className="w-8 h-8 rounded-lg object-cover" />
                                )}
                                <div>
                                  <p className="font-bold text-xs">{item.product_name}</p>
                                  <p className="text-gray-500 text-xs">×{item.quantity} • {item.price} ر.س</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Pricing */}
                        <div className="bg-white rounded-xl p-3 text-sm space-y-1">
                          <div className="flex justify-between"><span className="text-gray-500">المجموع</span><span className="font-bold">{order.subtotal} ر.س</span></div>
                          {order.discount_amount > 0 && <div className="flex justify-between text-green-600"><span>خصم ({order.discount_code})</span><span className="font-bold">- {order.discount_amount} ر.س</span></div>}
                          <div className="flex justify-between"><span className="text-gray-500">التوصيل</span><span className="font-bold">{order.delivery_fee} ر.س</span></div>
                          <div className="flex justify-between font-black border-t pt-1 mt-1"><span>الإجمالي</span><span className="text-pink-600">{order.total} ر.س</span></div>
                        </div>

                        {/* Receipt */}
                        {order.receipt_url && (
                          <div>
                            <p className="font-black text-sm mb-2">إيصال التحويل:</p>
                            <a href={order.receipt_url} target="_blank" rel="noopener noreferrer">
                              <img src={order.receipt_url} alt="إيصال" className="w-full max-w-xs rounded-xl border border-pink-200" />
                            </a>
                          </div>
                        )}

                        {/* Address */}
                        {order.delivery_address && (
                          <div>
                            <p className="font-black text-sm mb-1">عنوان التوصيل:</p>
                            <p className="text-xs text-gray-600 bg-white rounded-xl p-2">{order.delivery_address}</p>
                          </div>
                        )}

                        {order.notes && (
                          <div>
                            <p className="font-black text-sm mb-1">ملاحظات:</p>
                            <p className="text-xs text-gray-600 bg-white rounded-xl p-2">{order.notes}</p>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
