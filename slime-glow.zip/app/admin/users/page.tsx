'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Profile } from '@/types'
import { motion } from 'framer-motion'
import { Search, MessageCircle, Shield, User, ShoppingBag } from 'lucide-react'
import { useAuthStore } from '@/lib/store/auth'
import toast from 'react-hot-toast'

export default function AdminUsersPage() {
  const [users, setUsers] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const currentUser = useAuthStore(s => s.user)

  useEffect(() => { fetchUsers() }, [])

  const fetchUsers = async () => {
    const supabase = createClient()
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false })
    setUsers(data || [])
    setLoading(false)
  }

  const setRole = async (userId: string, role: 'customer' | 'supervisor' | 'admin') => {
    if (userId === currentUser?.id) { toast.error('لا يمكنك تغيير دورك الخاص'); return }
    const supabase = createClient()
    await supabase.from('profiles').update({ role }).eq('id', userId)
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, role } : u))
    toast.success(`تم تغيير الدور إلى ${role === 'admin' ? 'مدير' : role === 'supervisor' ? 'مشرف' : 'عميل'} ✓`)
  }

  const openWhatsApp = (phone: string) => {
    window.open(`https://wa.me/${phone.replace('+', '')}`, '_blank')
  }

  const filtered = users.filter(u =>
    u.phone?.includes(search) || u.full_name?.toLowerCase().includes(search.toLowerCase())
  )

  const roleColors: Record<string, string> = {
    admin: 'bg-red-100 text-red-600',
    supervisor: 'bg-blue-100 text-blue-600',
    customer: 'bg-gray-100 text-gray-600',
  }

  const roleLabels: Record<string, string> = {
    admin: 'مدير',
    supervisor: 'مشرف',
    customer: 'عميل',
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="font-black text-xl">المستخدمين ({users.length})</h2>
        <div className="flex gap-3 text-xs font-bold">
          <span className="px-2.5 py-1 bg-red-50 text-red-600 rounded-lg">{users.filter(u => u.role === 'admin').length} مدير</span>
          <span className="px-2.5 py-1 bg-blue-50 text-blue-600 rounded-lg">{users.filter(u => u.role === 'supervisor').length} مشرف</span>
          <span className="px-2.5 py-1 bg-gray-50 text-gray-600 rounded-lg">{users.filter(u => u.role === 'customer').length} عميل</span>
        </div>
      </div>

      <div className="relative">
        <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث برقم الجوال أو الاسم..."
          className="input-pink pr-10" />
      </div>

      {loading ? (
        <div className="space-y-3">{[1,2,3,4,5].map(i => <div key={i} className="h-16 bg-white rounded-2xl animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl">
          <div className="text-5xl mb-3">👥</div>
          <p className="font-bold text-gray-400">لا توجد نتائج</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((user, i) => (
            <motion.div key={user.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
              className="bg-white rounded-2xl border border-pink-100 p-4 flex items-center gap-3 shadow-sm">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: 'var(--secondary)' }}>
                <User size={20} style={{ color: 'var(--primary-dark)' }} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-bold text-sm">{user.full_name || 'بدون اسم'}</p>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${roleColors[user.role]}`}>
                    {roleLabels[user.role]}
                  </span>
                </div>
                <p className="text-xs text-gray-400" dir="ltr">{user.phone}</p>
              </div>

              {/* Role change - only admin can change */}
              {currentUser?.role === 'admin' && user.id !== currentUser.id && (
                <select
                  value={user.role}
                  onChange={e => setRole(user.id, e.target.value as any)}
                  className="text-xs font-bold border border-gray-200 rounded-xl px-2 py-1.5 bg-white focus:outline-none focus:border-pink-400 cursor-pointer"
                >
                  <option value="customer">عميل</option>
                  <option value="supervisor">مشرف</option>
                  <option value="admin">مدير</option>
                </select>
              )}

              {/* WhatsApp */}
              <button onClick={() => openWhatsApp(user.phone)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 text-green-600 rounded-xl text-xs font-bold hover:bg-green-100 transition-colors border border-green-200">
                <MessageCircle size={13} />
                واتساب
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
