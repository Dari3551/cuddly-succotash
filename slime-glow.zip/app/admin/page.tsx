'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { motion } from 'framer-motion'
import { ShoppingBag, Users, Eye, TrendingUp, Clock, CheckCircle, AlertCircle } from 'lucide-react'

interface Stats {
  totalOrders: number
  pendingOrders: number
  totalRevenue: number
  totalUsers: number
  visits: number
  todayOrders: number
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({ totalOrders: 0, pendingOrders: 0, totalRevenue: 0, totalUsers: 0, visits: 0, todayOrders: 0 })
  const [recentOrders, setRecentOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      const supabase = createClient()
      const today = new Date(); today.setHours(0,0,0,0)

      const [
        { count: totalOrders },
        { count: pendingOrders },
        { data: revenue },
        { count: totalUsers },
        { count: visits },
        { count: todayOrders },
        { data: orders }
      ] = await Promise.all([
        supabase.from('orders').select('*', { count: 'exact', head: true }),
        supabase.from('orders').select('*', { count: 'exact', head: true }).eq('order_status', 'pending'),
        supabase.from('orders').select('total').neq('order_status', 'cancelled'),
        supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'customer'),
        supabase.from('page_visits').select('*', { count: 'exact', head: true }),
        supabase.from('orders').select('*', { count: 'exact', head: true }).gte('created_at', today.toISOString()),
        supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(5),
      ])

      const totalRevenue = revenue?.reduce((sum, o) => sum + o.total, 0) || 0
      setStats({
        totalOrders: totalOrders || 0,
        pendingOrders: pendingOrders || 0,
        totalRevenue,
        totalUsers: totalUsers || 0,
        visits: visits || 0,
        todayOrders: todayOrders || 0,
      })
      setRecentOrders(orders || [])
      setLoading(false)
    }
    fetchStats()
  }, [])

  const cards = [
    { label: 'إجمالي الطلبات', value: stats.totalOrders, icon: ShoppingBag, color: 'from-pink-400 to-rose-500', emoji: '🛍️' },
    { label: 'طلبات معلقة', value: stats.pendingOrders, icon: Clock, color: 'from-amber-400 to-orange-500', emoji: '⏳' },
    { label: 'الإيرادات (ر.س)', value: stats.totalRevenue.toFixed(0), icon: TrendingUp, color: 'from-emerald-400 to-teal-500', emoji: '💰' },
    { label: 'العملاء', value: stats.totalUsers, icon: Users, color: 'from-violet-400 to-purple-500', emoji: '👥' },
    { label: 'الزوار', value: stats.visits, icon: Eye, color: 'from-blue-400 to-cyan-500', emoji: '👁️' },
    { label: 'طلبات اليوم', value: stats.todayOrders, icon: CheckCircle, color: 'from-pink-500 to-fuchsia-500', emoji: '🎀' },
  ]

  const statusMap: Record<string, { label: string; color: string }> = {
    pending: { label: 'معلق', color: 'text-yellow-600 bg-yellow-50' },
    preparing: { label: 'جاري التجهيز', color: 'text-blue-600 bg-blue-50' },
    out_for_delivery: { label: 'في الطريق', color: 'text-purple-600 bg-purple-50' },
    delivered: { label: 'مُسلَّم', color: 'text-green-600 bg-green-50' },
    cancelled: { label: 'ملغي', color: 'text-red-600 bg-red-50' },
  }

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {cards.map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="bg-white rounded-2xl p-5 shadow-sm border border-pink-100"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-500 font-medium text-sm">{card.label}</p>
                <p className="font-black text-2xl mt-1">{loading ? '...' : card.value}</p>
              </div>
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center text-white`}>
                <card.icon size={20} />
              </div>
            </div>
            <p className="text-2xl mt-2">{card.emoji}</p>
          </motion.div>
        ))}
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-pink-100">
        <h3 className="font-black text-lg mb-4">آخر الطلبات</h3>
        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => <div key={i} className="h-12 bg-pink-50 rounded-xl animate-pulse" />)}
          </div>
        ) : recentOrders.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <ShoppingBag size={40} className="mx-auto mb-2 opacity-30" />
            <p className="font-semibold">لا توجد طلبات بعد</p>
          </div>
        ) : (
          <div className="space-y-2">
            {recentOrders.map(order => {
              const s = statusMap[order.order_status]
              return (
                <div key={order.id} className="flex items-center justify-between p-3 rounded-xl hover:bg-pink-50 transition-colors">
                  <div>
                    <p className="font-bold text-sm">{order.order_number}</p>
                    <p className="text-xs text-gray-400">{order.customer_phone}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-xs font-bold px-2.5 py-1 rounded-lg ${s?.color}`}>{s?.label}</span>
                    <span className="font-black text-pink-600">{order.total} ر.س</span>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
