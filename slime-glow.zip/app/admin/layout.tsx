'use client'
import { useEffect, useState } from 'react'
import { useAuthStore } from '@/lib/store/auth'
import { createClient } from '@/lib/supabase/client'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import {
  LayoutDashboard, Package, Grid3X3, Tag, Settings,
  Users, ShoppingBag, BarChart3, ChevronLeft, LogOut,
  Sparkles, Menu, X
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const navItems = [
  { href: '/admin', icon: LayoutDashboard, label: 'لوحة التحكم' },
  { href: '/admin/orders', icon: ShoppingBag, label: 'الطلبات' },
  { href: '/admin/products', icon: Package, label: 'المنتجات' },
  { href: '/admin/categories', icon: Grid3X3, label: 'الأقسام' },
  { href: '/admin/discounts', icon: Tag, label: 'أكواد الخصم' },
  { href: '/admin/users', icon: Users, label: 'المستخدمين' },
  { href: '/admin/settings', icon: Settings, label: 'الإعدادات' },
]

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = useAuthStore(s => s.user)
  const setUser = useAuthStore(s => s.setUser)
  const router = useRouter()
  const pathname = usePathname()
  const [loading, setLoading] = useState(true)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    const checkAuth = async () => {
      const supabase = createClient()
      const { data: { user: authUser } } = await supabase.auth.getUser()
      if (!authUser) { router.push('/auth'); return }
      const { data: profile } = await supabase.from('profiles').select('*').eq('id', authUser.id).single()
      if (!profile || !['admin', 'supervisor'].includes(profile.role)) {
        router.push('/')
        return
      }
      setUser(profile)
      setLoading(false)
    }
    checkAuth()
  }, [])

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    setUser(null)
    router.push('/')
  }

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg)' }}>
      <div className="text-center">
        <div className="spinner mx-auto mb-4" />
        <p className="font-bold text-gray-500">جاري التحقق من الصلاحيات...</p>
      </div>
    </div>
  )

  return (
    <div className="flex min-h-screen" style={{ direction: 'rtl', background: 'var(--bg)' }}>
      {/* Mobile overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence>
        <motion.aside
          initial={{ x: '100%' }}
          animate={{ x: sidebarOpen ? 0 : '100%' }}
          className="fixed top-0 right-0 bottom-0 w-72 admin-sidebar z-50 md:relative md:translate-x-0 md:animate-none"
          style={{ display: 'flex', flexDirection: 'column' }}
        >
          <div className="hidden md:flex" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            <SidebarContent pathname={pathname} navItems={navItems} handleLogout={handleLogout} user={user} />
          </div>
        </motion.aside>
      </AnimatePresence>

      {/* Desktop sidebar - always visible */}
      <aside className="hidden md:flex flex-col w-64 admin-sidebar flex-shrink-0">
        <SidebarContent pathname={pathname} navItems={navItems} handleLogout={handleLogout} user={user} />
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="bg-white border-b border-pink-100 px-4 py-3 flex items-center gap-3">
          <button onClick={() => setSidebarOpen(true)} className="md:hidden p-2 rounded-xl hover:bg-pink-50">
            <Menu size={22} style={{ color: 'var(--primary-dark)' }} />
          </button>
          <h2 className="font-black text-lg flex-1">
            {navItems.find(n => n.href === pathname)?.label || 'الإدارة'}
          </h2>
          <Link href="/" className="flex items-center gap-1 text-xs font-bold text-gray-500 hover:text-pink-500">
            <ChevronLeft size={14} />
            المتجر
          </Link>
        </header>

        <main className="flex-1 p-4 md:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  )
}

function SidebarContent({ pathname, navItems, handleLogout, user }: any) {
  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 slime-blob flex items-center justify-center text-xl">✨</div>
          <div>
            <p className="font-black text-white text-sm">Slime & Glow</p>
            <p className="text-xs text-pink-200">لوحة التحكم</p>
          </div>
        </div>
        <div className="mt-3 px-3 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.1)' }}>
          <p className="text-white font-bold text-sm">{user?.full_name || user?.phone}</p>
          <p className="text-pink-200 text-xs">{user?.role === 'admin' ? 'مدير' : 'مشرف'}</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map(({ href, icon: Icon, label }: any) => {
          const isActive = pathname === href
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm transition-all ${
                isActive
                  ? 'bg-white text-pink-600'
                  : 'text-white/80 hover:bg-white/10 hover:text-white'
              }`}
            >
              <Icon size={18} />
              {label}
            </Link>
          )
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-white/10">
        <button onClick={handleLogout}
          className="flex items-center gap-2 text-white/70 hover:text-white font-bold text-sm w-full px-4 py-2 rounded-xl hover:bg-white/10 transition-all">
          <LogOut size={16} />
          تسجيل الخروج
        </button>
      </div>
    </div>
  )
}
