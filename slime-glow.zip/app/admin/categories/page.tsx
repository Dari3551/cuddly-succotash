'use client'
import { useEffect, useState, useRef } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Category } from '@/types'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Pencil, Trash2, GripVertical, X, ImagePlus } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState({ name: '', slug: '', description: '', image_url: '', is_active: true })
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => { fetchCategories() }, [])

  const fetchCategories = async () => {
    const supabase = createClient()
    const { data } = await supabase.from('categories').select('*').order('sort_order')
    setCategories(data || [])
    setLoading(false)
  }

  const slugify = (text: string) =>
    text.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]/g, '').replace(/\-\-+/g, '-')

  const openEdit = (cat: Category) => {
    setForm({ name: cat.name, slug: cat.slug, description: cat.description || '', image_url: cat.image_url || '', is_active: cat.is_active })
    setEditingId(cat.id)
    setShowForm(true)
  }

  const handleImageUpload = async (file: File) => {
    setUploading(true)
    const supabase = createClient()
    const path = `categories/${Date.now()}_${file.name.replace(/\s/g, '_')}`
    const { error } = await supabase.storage.from('products').upload(path, file)
    if (!error) {
      const url = supabase.storage.from('products').getPublicUrl(path).data.publicUrl
      setForm(f => ({ ...f, image_url: url }))
      toast.success('تم رفع الصورة ✓')
    }
    setUploading(false)
  }

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('اسم القسم مطلوب'); return }
    setSaving(true)
    const supabase = createClient()
    const slug = form.slug || slugify(form.name)
    const payload = { name: form.name.trim(), slug, description: form.description || null, image_url: form.image_url || null, is_active: form.is_active }

    if (editingId) {
      await supabase.from('categories').update(payload).eq('id', editingId)
      toast.success('تم تحديث القسم ✓')
    } else {
      const maxOrder = Math.max(0, ...categories.map(c => c.sort_order))
      await supabase.from('categories').insert({ ...payload, sort_order: maxOrder + 1 })
      toast.success('تم إضافة القسم ✓')
    }
    setSaving(false)
    setShowForm(false)
    setEditingId(null)
    setForm({ name: '', slug: '', description: '', image_url: '', is_active: true })
    fetchCategories()
  }

  const handleDelete = async (id: string) => {
    if (!confirm('حذف هذا القسم؟ المنتجات لن تُحذف.')) return
    const supabase = createClient()
    await supabase.from('categories').delete().eq('id', id)
    toast.success('تم الحذف')
    fetchCategories()
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="font-black text-xl">الأقسام ({categories.length})</h2>
        <button onClick={() => { setForm({ name: '', slug: '', description: '', image_url: '', is_active: true }); setEditingId(null); setShowForm(true) }}
          className="btn-pink !py-2.5">
          <Plus size={18} /> إضافة قسم
        </button>
      </div>

      {/* Form Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={e => e.target === e.currentTarget && setShowForm(false)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }}
              className="bg-white rounded-3xl p-6 w-full max-w-md">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-black text-xl">{editingId ? 'تعديل القسم' : 'إضافة قسم'}</h3>
                <button onClick={() => setShowForm(false)} className="w-9 h-9 rounded-xl bg-gray-100 flex items-center justify-center"><X size={18} /></button>
              </div>
              <div className="space-y-4">
                {/* Category Image */}
                <div>
                  <label className="block font-bold text-sm mb-2">صورة القسم</label>
                  <input ref={fileRef} type="file" accept="image/*" className="hidden"
                    onChange={e => e.target.files?.[0] && handleImageUpload(e.target.files[0])} />
                  {form.image_url ? (
                    <div className="relative w-24 h-24">
                      <img src={form.image_url} alt="" className="w-full h-full object-cover rounded-xl" />
                      <button onClick={() => setForm(f => ({ ...f, image_url: '' }))}
                        className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs">×</button>
                    </div>
                  ) : (
                    <button onClick={() => fileRef.current?.click()} disabled={uploading}
                      className="w-24 h-24 border-2 border-dashed border-pink-300 rounded-xl flex flex-col items-center justify-center gap-1 hover:bg-pink-50 transition-colors">
                      {uploading ? <div className="spinner w-6 h-6" /> : <><ImagePlus size={20} className="text-pink-400" /><span className="text-xs text-pink-400">رفع</span></>}
                    </button>
                  )}
                </div>
                <div>
                  <label className="block font-bold text-sm mb-1.5">اسم القسم *</label>
                  <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value, slug: slugify(e.target.value) }))}
                    placeholder="مثال: سلايمات" className="input-pink" />
                </div>
                <div>
                  <label className="block font-bold text-sm mb-1.5">الرابط (slug)</label>
                  <input value={form.slug} onChange={e => setForm(f => ({ ...f, slug: e.target.value }))}
                    placeholder="slimes" className="input-pink" dir="ltr" />
                </div>
                <div>
                  <label className="block font-bold text-sm mb-1.5">الوصف</label>
                  <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                    placeholder="وصف القسم..." className="input-pink" />
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <div onClick={() => setForm(f => ({ ...f, is_active: !f.is_active }))}
                    className={`w-12 h-6 rounded-full transition-colors relative ${form.is_active ? 'bg-pink-500' : 'bg-gray-300'}`}>
                    <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.is_active ? 'translate-x-6 right-0.5' : 'right-0.5'}`} />
                  </div>
                  <span className="font-bold text-sm">مفعّل</span>
                </label>
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setShowForm(false)} className="btn-outline flex-1 justify-center">إلغاء</button>
                <button onClick={handleSave} disabled={saving} className="btn-pink flex-1 justify-center disabled:opacity-60">
                  {saving ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : 'حفظ'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-16 bg-white rounded-2xl animate-pulse" />)}</div>
      ) : categories.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl">
          <div className="text-5xl mb-3">📁</div>
          <p className="font-bold text-gray-400 mb-3">لا توجد أقسام</p>
          <button onClick={() => setShowForm(true)} className="btn-pink"><Plus size={16} /> أضف قسماً</button>
        </div>
      ) : (
        <div className="space-y-2">
          {categories.map((cat, i) => (
            <motion.div key={cat.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
              className={`bg-white rounded-2xl border p-4 flex items-center gap-3 shadow-sm ${cat.is_active ? 'border-pink-100' : 'border-gray-200 opacity-60'}`}>
              <GripVertical size={18} className="text-gray-300 flex-shrink-0" />
              {cat.image_url ? (
                <img src={cat.image_url} alt={cat.name} className="w-10 h-10 rounded-xl object-cover flex-shrink-0" />
              ) : (
                <div className="w-10 h-10 rounded-xl bg-pink-100 flex items-center justify-center flex-shrink-0 text-lg">📁</div>
              )}
              <div className="flex-1">
                <p className="font-black">{cat.name}</p>
                <p className="text-xs text-gray-400">{cat.slug} {!cat.is_active && '• مخفي'}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => openEdit(cat)}
                  className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100 transition-colors flex items-center gap-1">
                  <Pencil size={12} /> تعديل
                </button>
                <button onClick={() => handleDelete(cat.id)}
                  className="px-3 py-1.5 bg-red-50 text-red-500 rounded-xl text-xs font-bold hover:bg-red-100 transition-colors flex items-center gap-1">
                  <Trash2 size={12} /> حذف
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
